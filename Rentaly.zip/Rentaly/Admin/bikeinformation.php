<?php
include('includes/header.php');
include('includes/topbar.php');
include('includes/sidebar.php');
?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Bike Information</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Bike</a></li>
                <li class="breadcrumb-item active">Information</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">


              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Bike Information Data table</h3>
                  <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add" style="margin-left:75%"><i class="fa fa-plus">Add</i>
                  </button>
                  <div class="modal fade" id="add">
                    <div class="modal-dialog modal-lg">
                    <form action="code.php" method="POST" enctype="multipart/form-data">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Add Information</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="card card-primary">
                            <div class="card-body">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Bike</label>
                                <input type="text" class="form-control" row="5" id="" name="bike_name" placeholder="Enter Bike Name.." required>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Model</label>
                                <input type="text" class="form-control" row="5" id="" name="model" placeholder="Enter model .." required>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Specs</label>
                                <input type="text" class="form-control" row="5" id="" name="size" placeholder="Enter Specs .." required>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Color</label>
                                <input type="text" class="form-control" row="5" id="" name="color" placeholder="Enter color .." required>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Price/HRS</label>
                                <input type="number" class="form-control" id="" name="price_per_hour" placeholder="00.00" required>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Price/Day</label>
                                <input type="number" class="form-control" id="" name="price_per_day" placeholder="00.00" required>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Img</label>
                                <input type="file" name="img" class="form-control" id="img" accept="image/*" required>
                              </div>
                            </div>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                            <button type="submit" name="add_bike" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                          </div>
                        </div>
                      </form>
                      <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                  </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">

                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Sr No</th>
                        <th>Bike Name</th>
                        <th>Model</th>
                        <th>Bike Color</th>
                        <th>Bike Specs</th>
                        <th>Rent Price Hrs</th>
                        <th>Rent Price Day</th>
                        <th width="7%"></th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php
                        $selectquery = " select * from bikes ";
                        $query = mysqli_query($connection, $selectquery);
                        $no=1;
                        while ($result = mysqli_fetch_assoc($query)) {
                        ?>
                      <tr>
                        <td><?php echo $no;?></td>
                        <td><?php echo $result['bike_name'];?></td>
                        <td><?php echo $result['model'];?></td>
                        <td><?php echo $result['color'];?></td>
                        <td><?php echo $result['size'];?></td>
                        <td><?php echo $result['price_per_hour'];?></td>
                        <td><?php echo $result['price_per_day'];?></td>
                        <td>
                          <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#update"><i class="fa fa-pencil-alt"></i>
                          </button>
                          <button type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                      <?php
                      $no++;
                  }
                  ?>
                    </tbody>
                  </table>
                  <!-- <div class="modal fade" id="update">
                    <div class="modal-dialog modal-sm">
                      <form action="add_manufacturer.php" method="post">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Update Information</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="card card-primary">
                            <div class="card-body">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Bike</label>
                                <input type="text" class="form-control" row="5" id="" name="category_name" placeholder="Enter Bike Name..">
                              </div>

                              <div class="form-group">
                                <label for="exampleInputEmail1">Category</label>
                                <select class="form-control">
                                  <option>Data</option>
                                  <option>Data</option>
                                </select>
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Specs</label>
                                <input type="text" class="form-control" row="5" id="" name="specs" placeholder="Enter Specs ..">
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Price</label>
                                <input type="number" class="form-control" id="" name="price" placeholder="00.00">
                              </div>
                              <div class="form-group">
                                <label for="exampleInputEmail1">Availability</label>
                                <input type="text" class="form-control" id="" name="avail" placeholder="Enter Availability ..">
                              </div>
                            </div>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div> -->
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php
include('includes/footer.php');
?>