
<?php
include('includes/header.php');
include('includes/topbar.php');
include('includes/sidebar.php');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Rental</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Bike</a></li>
              <li class="breadcrumb-item active">Rental</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
       

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Rental Form Data table</h3> 
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add" style="margin-left:78%"><i class="fa fa-plus">Add</i>
                </button>
                <div class="modal fade" id="add">
                        <div class="modal-dialog modal-lg">
                           <form action="add_manufacturer.php" method="post" >
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Add Client</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                              <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">First Name</label>
                                 <input type="text" class="form-control" row="5" id="" name="" placeholder="                -   First Name  -                 ">
                                </div>
                              </div>
                                <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Middle Name</label>
                                  <input type="text" class="form-control" row="5" id="" name="" placeholder="              -   Middle Name  -                 ">
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Last Name</label>
                                   <input type="text" class="form-control" row="5" id="" name="" placeholder="                -   Last Name  -                 ">
                                </div>
                              </div>
                                 <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Complete Address</label>
                                  <input type="text" class="form-control" id="" name="" placeholder="Enter Complete Addresss..">
                                </div>
                              </div>
                               <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Contact Number</label>
                                  <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter Contact Number..">
                                </div>
                              </div>
                               <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Email Address</label>
                                  <input type="text" class="form-control" row="5" id="" name="rental_code" placeholder="Enter Email Address..">
                                </div>
                              </div>
                               <div class="col-3">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Gender</label>
                                  <select class="form-control">
                                    <option>Male</option>
                                    <option>Female</option>
                                  </select>
                                </div>
                              </div>
                               <div class="col-3">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Civil Status</label>
                                  <input type="text" class="form-control" id="" name="rental_code" placeholder="Enter Civil Status..">
                                </div>
                              </div>
                               <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Birthdate</label>
                                  <input type="date" class="form-control"  id="" name="remarks">
                                </div>
                              </div>
                              <div class="col-2">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Age</label>
                                  <input type="text" class="form-control"  id="" placeholder="Age..">
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Username</label>
                                  <input type="text" class="form-control"  id="" placeholder="Enter Username">
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Password</label>
                                  <input type="password" class="form-control"  id="" placeholder="Enter Password..">
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Account Status</label>
                                  <input type="text" class="form-control"  id="" placeholder="Enter Account Status..">
                                </div>
                              </div>
                              <div class="col-3">
                                <div class="form-group">
                                 <label for="exampleInputEmail1">Profile Picture</label>
                                  <input type="file"   id="" >
                                </div>
                              </div>
                              </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">

                <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Fullname</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>User Category</th>
                    <th>Address</th>
                    <th>Date Of Birth</th>
                    <th width="7%"></th>
                  </tr>
                </thead>
                <tbody>
                <?php
                        $selectquery = "SELECT * FROM `customers`WHERE 	usertype='user' ";
                        $query = mysqli_query($connection, $selectquery);
                        $no=1;
                        while ($result = mysqli_fetch_assoc($query)) {
                        ?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $result['first_name'];?><?php echo $result['last_name'];?></td>
                    <td><?php echo $result['username'];?></td>
                    <td><?php echo $result['password'];?></td>
                    <td><?php echo $result['phone_number'];?></td>
                    <td><?php echo $result['email'];?></td>
                    <td><?php echo $result['usertype'];?></td>
                    <td><?php echo $result['Addresh'];?></td>
                    <td><?php echo $result['date_of_birth'];?></td>
                    <td>
                      <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#update"><i class="fa fa-pencil-alt"></i>
                      </button>
                      <button type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                  <?php
                      $no++;
                  }
                  ?>
                </tbody>
              </table>
            <!--<div class="modal fade" id="update">-->
            <!--            <div class="modal-dialog modal-lg">-->
            <!--            <form action="add_manufacturer.php" method="post" >-->
            <!--              <div class="modal-content">-->
            <!--                <div class="modal-header">-->
            <!--                  <h4 class="modal-title">Update Client</h4>-->
            <!--                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
            <!--                    <span aria-hidden="true">&times;</span>-->
            <!--                  </button>-->
            <!--                </div>-->
            <!--                <div class="card card-primary">-->
            <!--                  <div class="card-body">-->
            <!--                    <div class="row">-->
            <!--                  <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">First Name</label>-->
            <!--                     <input type="text" class="form-control" row="5" id="" name="" placeholder="                -   First Name  -                 ">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                    <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Middle Name</label>-->
            <!--                      <input type="text" class="form-control" row="5" id="" name="" placeholder="              -   Middle Name  -                 ">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                      <label for="exampleInputEmail1">Last Name</label>-->
            <!--                       <input type="text" class="form-control" row="5" id="" name="" placeholder="                -   Last Name  -                 ">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                     <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Complete Address</label>-->
            <!--                      <input type="text" class="form-control" id="" name="" placeholder="Enter Complete Addresss..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                   <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Contact Number</label>-->
            <!--                      <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter Contact Number..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                   <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Email Address</label>-->
            <!--                      <input type="text" class="form-control" row="5" id="" name="rental_code" placeholder="Enter Email Address..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                   <div class="col-3">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Gender</label>-->
            <!--                      <select class="form-control">-->
            <!--                        <option>Male</option>-->
            <!--                        <option>Female</option>-->
            <!--                      </select>-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                   <div class="col-3">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Civil Status</label>-->
            <!--                      <input type="text" class="form-control" id="" name="rental_code" placeholder="Enter Civil Status..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                   <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Birthdate</label>-->
            <!--                      <input type="date" class="form-control"  id="" name="remarks">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  <div class="col-2">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Age</label>-->
            <!--                      <input type="text" class="form-control"  id="" placeholder="Age..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Username</label>-->
            <!--                      <input type="text" class="form-control"  id="" placeholder="Enter Username">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Password</label>-->
            <!--                      <input type="password" class="form-control"  id="" placeholder="Enter Password..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  <div class="col-4">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Account Status</label>-->
            <!--                      <input type="text" class="form-control"  id="" placeholder="Enter Account Status..">-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  <div class="col-3">-->
            <!--                    <div class="form-group">-->
            <!--                     <label for="exampleInputEmail1">Profile Picture</label>-->
            <!--                      <input type="file"   id="" >-->
            <!--                    </div>-->
            <!--                  </div>-->
            <!--                  </div>-->
            <!--                  </div>-->
            <!--              </div>-->
            <!--                <div class="modal-footer justify-content-between">-->
            <!--                  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>-->
            <!--                  <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>-->
            <!--                </div>-->
            <!--              </div>-->
            <!--              </form>-->
                          <!-- /.modal-content -->
                        <!--</div>-->
                        <!-- /.modal-dialog -->
                      <!--</div>-->
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php
include('includes/footer.php');
?>