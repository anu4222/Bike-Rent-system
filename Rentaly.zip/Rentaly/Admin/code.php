<?php

include('security.php');
if (isset($_SESSION['auth'])) {
    $user = $_SESSION['auth_user']['username'];
  }
  ?>
  <?php if (isset($_SESSION['auth'])) {
    $userid = $_SESSION['auth_user']['user_id'];
  }
  
if(isset($_POST['add_bike']))
{
            $bike_name = $_POST['bike_name'];
            $model = $_POST['model'];
            $color = $_POST['color'];
            $size = $_POST['size'];
            $price_per_hour = $_POST['price_per_hour'];
            $price_per_day = $_POST['price_per_day'];
            $img = $_FILES["img"]['name'];
          if(file_exists("./img/".$_FILES["img"]["name"]))
           {
               $store = $_FILES["img"]["name"];
               $_SESSION['status'] = "Picture Alredy Exists. '.$store'";
               header('Location:bikeinformation.php');
           }
       else
       {
        $query= "INSERT INTO `bikes`(`bike_name`, `model`, `color`, `size`, `price_per_hour`, `price_per_day`, `img`) VALUES ('$bike_name','$model','$color','$size','$price_per_hour','$price_per_day','$img')";
           $query_run = mysqli_query($connection, $query);
       
           if($query_run)
           { 
               move_uploaded_file($_FILES["img"]["tmp_name"], "./img/" . $_FILES["img"]["name"]);
               $_SESSION['status'] = "Bike Add Successfull";
               $_SESSION['status_code'] = "success";
               header('Location: bikeinformation.php'); 
           }
           else
           {
               $_SESSION['status'] = "Oops Somthing Went Worng!";
               $_SESSION['status_code'] = "error";
               header('Location: bikeinformation.php'); 
   }   
 
  }
}
  
  if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $password = $_POST['edit_password'];
    $query = "UPDATE register SET password='$password' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your password is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Password is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: index.php'); 
    }
}


 

?>