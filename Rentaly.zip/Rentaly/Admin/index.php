<?php
include('includes/header.php');
include('includes/topbar.php');
include('includes/sidebar.php');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-4 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3>
                <?php
                $query = "SELECT * FROM `customers`WHERE 	usertype='user'";
                $query_run = mysqli_query($connection, $query);
                $row = mysqli_num_rows($query_run);
                echo ' ' . $row . '';
                ?>
               </h3>

                <p>Total Clients</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="usermanagement.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-4 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3>
                <?php
                $query = "SELECT * FROM `bikes`";
                $query_run = mysqli_query($connection, $query);
                $row = mysqli_num_rows($query_run);
                echo ' ' . $row . '';
                ?>

                <sup style="font-size: 20px"></sup></h3>

                <p>Total Bike</p>
              </div>
              <div class="icon">
                <i class="fa fa-bicycle"></i>
              </div>
              <a href="bikeinformation.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-4 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>
                    <?php
                        $query3="SELECT SUM(total_cost) as 'sumtotal_cost' FROM `rentals` WHERE Status='1'";
                         $res3=mysqli_query($connection, $query3);
                         while($data3=mysqli_fetch_assoc($res3)){
                          $sale=  $data3['sumtotal_cost'];
                        }
                        ?>
                         <?php 
                        if($sale >=0){
                          $calc41 =  $sale;
                             }else{
                               $calc41 = 0;
                             } 
                             echo $calc41;
                              ?>
                </h3>

                <p>Total Rental Transaction</p>
              </div>
              <div class="icon">
                <i class="fa fa-edit"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
      
     
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php
include('includes/footer.php');
?>