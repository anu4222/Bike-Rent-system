<?php
include('includes/header.php');
include('includes/topbar.php');
include('includes/sidebar.php');
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Payment</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Payment</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">


          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Payment Form Data table</h3>
              <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add" style="margin-left:76%"><i class="fa fa-plus">Add</i>
              </button>
              <div class="modal fade" id="add">
                <div class="modal-dialog modal-md">
                  <form action="add_manufacturer.php" method="post">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Add Payment</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="card card-primary">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Rental Code</label>
                                <input type="text" class="form-control" row="5" id="" name="rental_code" placeholder="Enter Rental Code..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Payment Type</label>
                                <input type="text" class="form-control" id="" name="rental_code" placeholder="Enter Payment Type..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Paid By</label>
                                <input type="text" class="form-control" id="" name="rental_code" placeholder="Paid By..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Payment Date</label>
                                <input type="date" class="form-control" id="" name="">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Remarks</label>
                                <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter Remarks..">
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                      </div>
                    </div>
                  </form>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">

              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Rental Code</th>
                    <th>Payment Type</th>
                    <th>Paid By</th>
                    <th>Payment Date</th>
                    <th>Remarks</th>
                    <th>Processed By</th>
                    <th width="7%"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Data</td>
                    <td>Data</td>
                    <td>Data</td>
                    <td>Data</td>
                    <td>Data</td>
                    <td>Data</td>
                    <td>
                      <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#update"><i class="fa fa-pencil-alt"></i>
                      </button>
                      <button type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr>
                    <th>Rental Code</th>
                    <th>Payment Type</th>
                    <th>Paid By</th>
                    <th>Payment Date</th>
                    <th>Remarks</th>
                    <th>Processed By</th>
                    <th width="7%"></th>
                  </tr>
                </tfoot>
              </table>
              <div class="modal fade" id="update">
                <div class="modal-dialog modal-md">
                  <form action="add_manufacturer.php" method="post">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Update Payment</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="card card-primary">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Rental Code</label>
                                <input type="text" class="form-control" row="5" id="" name="rental_code" placeholder="Enter Rental Code..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Payment Type</label>
                                <input type="text" class="form-control" id="" name="rental_code" placeholder="Enter Payment Type..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Paid By</label>
                                <input type="text" class="form-control" id="" name="rental_code" placeholder="Paid By..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Payment Date</label>
                                <input type="date" class="form-control" id="" name="">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Remarks</label>
                                <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter Remarks..">
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                      </div>
                    </div>
                  </form>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php
include('includes/footer.php');
?>