<?php
session_start();
include('dbconfig.php');
if($connection)
{
    // echo "Database Connected";
}
else
{
    header("Location: dbconfig.php");
}

if(!isset($_SESSION['auth']))
    {
        $_SESSION['auth_status'] ="login success";
        header('Location: ../login.php');
        exit(0);
    }
    else
    {
       if($_SESSION['auth'] == "Admin")
       {

       }
       elseif($_SESSION['auth'] == "user")
       {
       
           $_SESSION['auth_status'] = "Welcome To XYZ";
           $_SESSION['status_code'] = "success";
           header('Location: ../User_Dashboard/index.php');
       }
    
       else
       {
           $_SESSION['status'] = "User Name & Password is Invalid";
           $_SESSION['status_code'] = "warning";
           header('Location: ../login.php');
       }
    }

?>