<?php
include('includes/header.php');
include('includes/topbar.php');
include('includes/sidebar.php');
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>User Management</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">User Management</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">


          <div class="card">
            <div class="card-header">
              <h3 class="card-title">User Management Data table</h3>
              <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add" style="margin-left:74%"><i class="fa fa-plus">Add</i>
              </button>
              <div class="modal fade" id="add">
                <div class="modal-dialog modal-md">
                  <form action="add_manufacturer.php" method="post">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Add User</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="card card-primary">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Fullname</label>
                                <input type="text" class="form-control" row="5" id="" name="" placeholder="Enter Fullname.. ">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input type="text" class="form-control" row="5" id="" name="" placeholder="Enter Username..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input type="text" class="form-control" row="5" id="" name="" placeholder="Enter Password..">
                              </div>
                            </div>
                            <div class="col-4">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Contact</label>
                                <input type="text" class="form-control" id="" name="" placeholder="Enter Contact..">
                              </div>
                            </div>
                            <div class="col-8">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter Email..">
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Barangay</label>
                                <input type="text" class="form-control" id="" name="rental_code" placeholder="Enter Barangay">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">User Category</label>
                                <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter User Category..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Status</label>
                                <select class="form-control">
                                  <option>Active</option>
                                  <option>Inactive</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-3">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Profile Picture</label>
                                <input type="file" id="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                      </div>
                    </div>
                  </form>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">

              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr No</th>
                    <th>Fullname</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>User Category</th>
                    <th>Address</th>
                    <th>Date Of Birth</th>
                    <th width="7%"></th>
                  </tr>
                </thead>
                <tbody>
                <?php
                        $selectquery = "SELECT * FROM `customers`WHERE 	usertype='user' ";
                        $query = mysqli_query($connection, $selectquery);
                        $no=1;
                        while ($result = mysqli_fetch_assoc($query)) {
                        ?>
                  <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $result['first_name'];?><?php echo $result['last_name'];?></td>
                    <td><?php echo $result['username'];?></td>
                    <td><?php echo $result['password'];?></td>
                    <td><?php echo $result['phone_number'];?></td>
                    <td><?php echo $result['email'];?></td>
                    <td><?php echo $result['usertype'];?></td>
                    <td><?php echo $result['Addresh'];?></td>
                    <td><?php echo $result['date_of_birth'];?></td>
                    <td>
                      <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#update"><i class="fa fa-pencil-alt"></i>
                      </button>
                      <button type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                  <?php
                      $no++;
                  }
                  ?>
                </tbody>
              </table>
              <!-- <div class="modal fade" id="update">
                <div class="modal-dialog modal-md">
                  <form action="add_manufacturer.php" method="post">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Update User</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="card card-primary">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Fullname</label>
                                <input type="text" class="form-control" row="5" id="" name="" placeholder="Enter Fullname.. ">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Username</label>
                                <input type="text" class="form-control" row="5" id="" name="" placeholder="Enter Username..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input type="text" class="form-control" row="5" id="" name="" placeholder="Enter Password..">
                              </div>
                            </div>
                            <div class="col-4">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Contact</label>
                                <input type="text" class="form-control" id="" name="" placeholder="Enter Contact..">
                              </div>
                            </div>
                            <div class="col-8">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter Email..">
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Barangay</label>
                                <input type="text" class="form-control" id="" name="rental_code" placeholder="Enter Barangay">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">User Category</label>
                                <input type="text" class="form-control" row="5" id="" name="re" placeholder="Enter User Category..">
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Status</label>
                                <select class="form-control">
                                  <option>Active</option>
                                  <option>Inactive</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-3">
                              <div class="form-group">
                                <label for="exampleInputEmail1">Profile Picture</label>
                                <input type="file" id="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Submit</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div> -->
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php
include('includes/footer.php');
?>