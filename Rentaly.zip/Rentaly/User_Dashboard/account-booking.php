<?php
include('includes/header.php');
include('includes/topbar.php');
?>
<!-- content begin -->
<div class="no-bottom no-top zebra" id="content">
  <div id="top"></div>

  <!-- section begin -->
  <section id="subheader" class="jarallax text-light">
    <img src="images/background/14.jpg" class="jarallax-img" alt="">
    <div class="center-y relative text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h1>My Orders</h1>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </section>
  <!-- section close -->

  <section id="section-settings" class="bg-gray-100">
    <div class="container">
      <div class="row">

        <?php
        include('includes/sidebar.php');
        ?>
        <div class="col-lg-9">

          <div class="card p-4 rounded-5 mb25">
            <h4>Scheduled Orders</h4>

            <table class="table de-table">
              <thead>
                <tr>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Order ID</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Bike Name</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Pick Up Date</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Return Date</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Status</span></th>
                </tr>
              </thead>

              <tbody>
                    <?php
                        $selectquery = "SELECT * FROM `rentals` WHERE customer_id='$user_id' AND Status='0' ";
                        $query = mysqli_query($connection, $selectquery);
                        $no=1;
                        while ($result = mysqli_fetch_assoc($query)) {
                        ?>
                <tr>
                  <td><span class="d-lg-none d-sm-block">Order ID</span>
                    <div class="badge bg-gray-100 text-dark"><?php echo $no; ?></div>
                  </td>
                  <td><span class="d-lg-none d-sm-block">Bike Name</span><span class="bold">
                    <?php $bike_id= $result['bike_id'];?>
                  <?php
                        $bikename = "SELECT * FROM `bikes` WHERE  bike_id='$bike_id' ";
                        $query_bike = mysqli_query($connection, $bikename);
                        while ($row = mysqli_fetch_assoc($query_bike)) {?>
                         <?php echo $row['bike_name']; ?> <?php echo $row['model']; ?>
                      <?php  }
                        ?>
                  </span></td>
                  <td><span class="d-lg-none d-sm-block">Pick Up Date</span><?php echo $result['rental_start_time'];  ?></td>
                  <td><span class="d-lg-none d-sm-block">Return Date</span><?php echo $result['rental_end_time'];  ?></td>
                  <td>
                    <div class="badge rounded-pill bg-warning">scheduled</div>
                  </td>
                </tr>
                <?php
                      $no++;
                  }
                  ?>
              </tbody>
            </table>
          </div>

          <div class="card p-4 rounded-5 mb25">
            <h4>Completed Orders</h4>

            <table class="table de-table">
              <thead>
                <tr>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Order ID</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Bike Name</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Pick Up Date</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Return Date</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Status</span></th>
                </tr>
              </thead>
              <tbody>
              <?php
                        $selectquery = " SELECT * FROM `rentals` WHERE	customer_id='$user_id' AND Status='1' ";
                        $query = mysqli_query($connection, $selectquery);
                        $no=1;
                        while ($result = mysqli_fetch_assoc($query)) {
                        ?>
                <tr>
                <td><span class="d-lg-none d-sm-block">Order ID</span>
                    <div class="badge bg-gray-100 text-dark"><?php echo $no; ?></div>
                  </td>
                  <td><span class="d-lg-none d-sm-block">Bike Name</span><span class="bold">
                      <?php $bike_id= $result['bike_id'];?>
                  <?php
                        $bikename = "SELECT * FROM `bikes` WHERE  bike_id='$bike_id' ";
                        $query_bike = mysqli_query($connection, $bikename);
                        while ($row = mysqli_fetch_assoc($query_bike)) {?>
                         <?php echo $row['bike_name']; ?> <?php echo $row['model']; ?>
                      <?php  }
                        ?>
                  </span></td>
                  <td><span class="d-lg-none d-sm-block">Pick Up Date</span><?php echo $result['rental_start_time'];  ?></td>
                  <td><span class="d-lg-none d-sm-block">Return Date</span><?php echo $result['rental_end_time'];  ?></td>
                    <div class="badge rounded-pill bg-success">completed</div>
                  </td>
                </tr>
                <?php
                      $no++;
                  }
                  ?>
              </tbody>
            </table>
          </div>

          <div class="card p-4 rounded-5 mb25">
            <h4>Cancelled Orders</h4>

            <table class="table de-table">
              <thead>
                <tr>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Order ID</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Bike Name</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Pick Up Date</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Return Date</span></th>
                  <th scope="col"><span class="text-uppercase fs-12 text-gray">Status</span></th>
                </tr>
              </thead>
              <tbody>
              <?php
                        $selectquery = "SELECT * FROM `rentals` WHERE	customer_id='$user_id' AND Status='2' ";
                        $query = mysqli_query($connection, $selectquery);
                        $no=1;
                        while ($result = mysqli_fetch_assoc($query)) {
                        ?>
                <tr>
                <td><span class="d-lg-none d-sm-block">Order ID</span>
                    <div class="badge bg-gray-100 text-dark"><?php echo $no; ?></div>
                  </td>
                  <td><span class="d-lg-none d-sm-block">Bike Name</span><span class="bold">
                      <?php $bike_id= $result['bike_id'];?>
                  <?php
                        $bikename = "SELECT * FROM `bikes` WHERE  bike_id='$bike_id' ";
                        $query_bike = mysqli_query($connection, $bikename);
                        while ($row = mysqli_fetch_assoc($query_bike)) {?>
                         <?php echo $row['bike_name']; ?> <?php echo $row['model']; ?>
                      <?php  }
                        ?>
                  </span></td>
                  <td><span class="d-lg-none d-sm-block">Pick Up Date</span><?php echo $result['rental_start_time'];  ?></td>
                  <td><span class="d-lg-none d-sm-block">Return Date</span><?php echo $result['rental_end_time'];  ?></td>
                  <td>
                    <div class="badge rounded-pill bg-danger">cancelled</div>
                  </td>
                </tr>
                <?php
                      $no++;
                  }
                  ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>


</div>
<!-- content close -->
<?php
include('includes/footer.php');
?>