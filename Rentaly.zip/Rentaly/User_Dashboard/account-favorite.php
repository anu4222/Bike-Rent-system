<?php
include('includes/header.php');
include('includes/topbar.php');
?>
<!-- content begin -->
<div class="no-bottom no-top zebra" id="content">
    <div id="top"></div>

    <!-- section begin -->
    <section id="subheader" class="jarallax text-light">
        <img src="images/background/14.jpg" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1>My Favorite Bike</h1>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->

    <section id="section-settings" class="bg-gray-100">
        <div class="container">
            <div class="row">
               <?php
                include('includes/sidebar.php');
                ?>
                <div class="col-lg-9">
                             <?php
                            $query ="SELECT * FROM `bikes` Limit 5";
                            $query_run = mysqli_query($connection,$query);
                            $check_faculty = mysqli_num_rows($query_run)>0;
                            if($check_faculty)
                            {
                            while($row= mysqli_fetch_assoc($query_run))
                            { ?>
                    <div class="de-item-list no-border mb30">
                        <div class="d-img">
                            <img src="../Admin/img/<?php echo$row['img']; ?>" class="img-fluid" alt="">
                        </div>
                        <div class="d-info">
                            <div class="d-text">
                                <h4><?php echo $row['bike_name']; ?><?php echo $row['model']; ?></h4>
                                <div class="d-atr-group">
                                    <ul class="d-atr">
                                        <li><span>Seats:</span><?php echo $row['size']; ?></li>
                                        <li><span>Fuel:</span>Petrol</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="d-price">
                            Daily rate from <span><?php echo $row['price_per_day']; ?></span>
                            <form action="bike-single.php" method="post">
                              <input type="hidden" name="bike_id" value="<?php echo $row['bike_id']; ?>">
                              <input type="submit" class="btn btn-success" value="Rent Now">
                            </form>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <?php
                                }
                                }
                             ?>
                    
                </div>
            </div>
        </div>
    </section>


</div>
<!-- content close -->
<?php
include('includes/footer.php');
?>