<?php
include('includes/header.php');
include('includes/topbar.php');
?>
<!-- content begin -->
<div class="no-bottom no-top zebra" id="content">
    <div id="top"></div>

    <!-- section begin -->
    <section id="subheader" class="jarallax text-light">
        <img src="images/background/14.jpg" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1>My Profile</h1>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->

    <section id="section-settings" class="bg-gray-100">
        <div class="container">
            <div class="row">
             <?php
                include('includes/sidebar.php');
                ?>
                 <div class="col-lg-9">
                    <div class="card p-4  rounded-5">
                        <div class="row">
                            <div class="col-lg-12">
                            <form class="form-border" action="code.php" method="post">
                                    <div class="de_tab tab_simple">

                                        <ul class="de_nav">
                                            <li class="active"><span>Profile</span></li>
                                            <li><span>Notifications </span></li>
                                        </ul>
                                     <?php 
                                      $query ="SELECT * FROM customers WHERE  customer_id='$user_id' ";
                                      $query_run =mysqli_query($connection,$query);
                                      foreach($query_run as $row)
                                    {
                                    ?>
                                    
                                        <div class="de_tab_content">
                                            <div class="tab-1">
                                                <div class="row">
                                                <div class="col-lg-6 mb20">
                                                        <h5>Fist Name</h5>
                                                        <input type="text" name="fist_name"  value="<?php echo $row['first_name']?>" class="form-control" placeholder="Enter Fist Name" readonly/>
                                                    </div>
                                                    <div class="col-lg-6 mb20">
                                                        <h5>Last Name</h5>
                                                        <input type="text" name="Last_name"  value="<?php echo $row['last_name']?>" class="form-control" placeholder="Enter Last Name" readonly />
                                                    </div>
                                                    <div class="col-lg-6 mb20">
                                                        <h5>Username</h5>
                                                        <input type="text"   value="<?php echo $row['username']?>" class="form-control" placeholder="Enter username" readonly/>
                                                    </div>
                                                    <div class="col-lg-6 mb20">
                                                        <h5>Email Address</h5>
                                                        <input type="text" name="email_address" value="<?php echo $row['email']?>" class="form-control" placeholder="Enter email" readonly/>
                                                    </div>
                                                    <div class="col-lg-6 mb20">
                                                        <h5>Mobile</h5>
                                                        <input type="text" name="mobile" value="<?php echo $row['phone_number']?>"  class="form-control" placeholder="Enter Mobile Number" readonly/>
                                                    </div>
                                                    <div class="col-lg-6 mb20">
                                                        <h5>Date Of Birth</h5>
                                                        <input type="date" name="date_of_birth" value="<?php echo $row['date_of_birth']?>" class="form-control" placeholder="date of birth" readonly/>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="tab-2">
                                                <div class="row">
                                                    <div class="col-md-6 mb-sm-20">
                                                        <div class="switch-with-title s2">
                                                            <h5>Discount Notifications</h5>
                                                            <div class="de-switch">
                                                                <input type="checkbox" id="notif-item-sold" class="checkbox">
                                                                <label for="notif-item-sold"></label>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <p class="p-info">You'll get notification while new discount available.</p>
                                                        </div>

                                                        <div class="spacer-20"></div>

                                                        <div class="switch-with-title s2">
                                                            <h5>New Product Notification</h5>
                                                            <div class="de-switch">
                                                                <input type="checkbox" id="notif-bid-activity" class="checkbox">
                                                                <label for="notif-bid-activity"></label>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <p class="p-info">You'll get notification while new product available.</p>
                                                        </div>

                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="switch-with-title s2">
                                                            <h5>Daily Reports</h5>
                                                            <div class="de-switch">
                                                                <input type="checkbox" id="notif-auction-expiration" class="checkbox">
                                                                <label for="notif-auction-expiration"></label>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <p class="p-info">We will send you a report everyday.</p>
                                                        </div>

                                                        <div class="spacer-20"></div>

                                                        <div class="switch-with-title s2">
                                                            <h5>Monthly Reports</h5>
                                                            <div class="de-switch">
                                                                <input type="checkbox" id="notif-outbid" class="checkbox">
                                                                <label for="notif-outbid"></label>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <p class="p-info">We will send you a report each month.</p>
                                                        </div>

                                                    </div>

                                                    <div class="spacer-20"></div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <button type="submit" name="update_profile" class="btn btn-success"> Update profile </button>
                                </form>
                                <?php   
                                }          
                                ?> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


</div>
<!-- content close -->
<?php
include('includes/footer.php');
?>