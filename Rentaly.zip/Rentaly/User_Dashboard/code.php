<?php

include('security.php');
if (isset($_SESSION['auth'])) {
    $user = $_SESSION['auth_user']['username'];
  }
  ?>
  <?php if (isset($_SESSION['auth'])) {
    $userid = $_SESSION['auth_user']['user_id'];
  }
  

  
  if(isset($_POST['update_profile']))
{
   
    $fist_name = $_POST['fist_name'];
    $Last_name = $_POST['Last_name'];
    $email_address = $_POST['email_address'];
    $mobile = $_POST['mobile'];
    $date_of_birth = $_POST['date_of_birth'];


    $query = "UPDATE `customers` SET `first_name`='$fist_name',`last_name`='$Last_name',`email`='$email_address',`phone_number`='$mobile',`date_of_birth`='$date_of_birth' WHERE `customer_id`='$userid' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Your Profile is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Your Password is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: index.php'); 
    }
}

if(isset($_POST['Book_bike']))
{
            $bike_id = $_POST['bike_id'];
            $Pick_date = $_POST['Pick_date'];
            $Pick_Time = $_POST['Pick_Time'];
            $Return_time = $_POST['Return_time'];
            $return_date = $_POST['return_date'];
           $start = strtotime($Pick_date);
			$end = strtotime($return_date);

		    $start = new DateTime($Pick_date);
            $end = new DateTime($return_date);
            $interval = $start->diff($end);
            $days = $interval->format("%R%a");
           $days = $days + 1;

            $selectquery = "SELECT * FROM `bikes` WHERE bike_id='$bike_id' ";
               $query = mysqli_query($connection, $selectquery);
               while ($result = mysqli_fetch_assoc($query)) {
                $qty = $result['price_per_day']; 
               }
             $total_amount= $days* $qty;
         $query= "INSERT INTO `rentals`(`Start_date`, `rental_start_time`, `rental_end_time`, `end_date`, `rental_duration_hours`, `total_cost`, `bike_id`, `customer_id`, `Status`) VALUES ('$Pick_date','$Pick_Time','$Return_time','$return_date','$days','$total_amount','$bike_id','$userid','0')";
            $query_run = mysqli_query($connection, $query);
       
            if($query_run)
            { 
                $_SESSION['status'] = "Bike Add Successfull";
                $_SESSION['status_code'] = "success";
                header('Location: account-booking.php'); 
            }
            else
            {
                $_SESSION['status'] = "Oops Somthing Went Worng!";
                $_SESSION['status_code'] = "error";
                header('Location: account-booking.phpp'); 
    }   
 
  }

 

?>