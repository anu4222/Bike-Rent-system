<div class="col-lg-3 mb30">
  <div class="card p-4 rounded-5">
    <div class="profile_avatar">
      <div class="profile_img">
        <img src="images/profile/1.jpg" alt="">
      </div>
      <div class="profile_name">
        <h4>  
            <?php echo $username ?>
          <span class="profile_username text-gray"><?php echo $email ?></span>
        </h4>
      </div>
    </div>
    <div class="spacer-20"></div>
    <?php  $page= substr($_SERVER['SCRIPT_NAME'], strrpos($_SERVER['SCRIPT_NAME'], "/")+1);?>
    <ul class="menu-col">
      <li><a href="index.php" class="<?=$page == 'index.php' ? 'active':''?>"><i class="fa fa-home"></i>Dashboard</a></li>
      <li><a href="account-profile.php" class="<?=$page == 'account-profile.php' ? 'active':''?>" ><i class="fa fa-user"></i>My Profile</a></li>
      <li><a href="account-booking.php"  class="<?=$page == 'account-booking.php' ? 'active':''?>"><i class="fa fa-calendar"></i>My Orders</a></li>
      <li><a href="account-favorite.php" class="<?=$page == 'account-favorite.php' ? 'active':''?>"><i class="fa fa-car"></i>My Favorite Bike</a></li>
      <li><a href="../logout.php"><i class="fa fa-sign-out"></i>Sign Out</a></li>
    </ul>
  </div>
</div>