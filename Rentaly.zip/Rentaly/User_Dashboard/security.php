<?php
session_start();
include('dbconfig.php');
if($connection)
{
    // echo "Database Connected";
}
else
{
    header("Location: dbconfig.php");
}

if(!isset($_SESSION['auth']))
    {
      
        if($_SESSION['auth'] == "Admin")
            
        {
        
            $_SESSION['auth_status'] = "Welcome To XYZ";
            $_SESSION['status_code'] = "success";
            header('Location: ../Admin/index.php');
        }
        else if($_SESSION['auth'] == "user")
        {
        
            $_SESSION['auth_status'] = "Welcome To XYZ";
            $_SESSION['status_code'] = "success";
            header('Location: User_Dashboard/index.php');
        }
        
        else
        {
            $_SESSION['auth_status'] ="login success";
            $_SESSION['status_code'] = "warning";
            header('Location: ../logout.php');
            exit(0);
        }
    }

?>