-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 24, 2023 at 05:58 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bike_rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `bikes`
--

DROP TABLE IF EXISTS `bikes`;
CREATE TABLE IF NOT EXISTS `bikes` (
  `bike_id` int(11) NOT NULL AUTO_INCREMENT,
  `bike_name` text DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `price_per_hour` decimal(10,2) DEFAULT NULL,
  `price_per_day` int(200) DEFAULT NULL,
  `img` text DEFAULT NULL,
  PRIMARY KEY (`bike_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bikes`
--

INSERT INTO `bikes` (`bike_id`, `bike_name`, `model`, `color`, `size`, `price_per_hour`, `price_per_day`, `img`) VALUES
(4, 'Bajaj Pulsar ', '150 Neon (BS6)', 'Yellow & Black', '2', '33.00', 600, 'BAJAJ_PULSAR_150_NEON_BS6.png'),
(3, 'TVS Apache RTR ', '160 BS6', 'Red', '2', '28.00', 500, 'Apache_RTR_160.png'),
(5, 'Honda ', 'X Blade  (BS6)', 'Red', '2', '36.00', 700, 'HONDA_X-BLADE_(BS6).png'),
(6, 'Suzuki ', 'Avenis 125', 'Black', '2', '24.00', 500, 'SUZUKI_AVENIS.png'),
(7, 'Yamaha ', 'Aerox', 'Blue And Black', '2', '25.00', 550, 'YAMAHA_AEROX.png');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `Addresh` text DEFAULT NULL,
  `password` text DEFAULT NULL,
  `usertype` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `username`, `first_name`, `last_name`, `email`, `phone_number`, `date_of_birth`, `Addresh`, `password`, `usertype`) VALUES
(1, 'Anurag', 'Anurag', 'Dwivedi', 'anuragdwivedi@656@gmail.com', '9559827326', NULL, 'Lucknow', '123', 'Admin'),
(2, 'Dwivedi', 'Anurag', 'Dwivedi', 'shfsd@gmail.com', '9559827326', '2023-04-11', 'lko', '123', 'user'),
(3, 'Anu4222', 'Anurag', 'Dwivedi', 'anuragdwivedi.genuselectrotech@gmail.com', '9559827326', '2023-04-20', 'Adampur Bhanshi Post Hasanganj Unnao\r\nHadanganj', '123', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

DROP TABLE IF EXISTS `rentals`;
CREATE TABLE IF NOT EXISTS `rentals` (
  `rental_id` int(11) NOT NULL AUTO_INCREMENT,
  `Start_date` varchar(200) DEFAULT NULL,
  `rental_start_time` datetime DEFAULT NULL,
  `rental_end_time` datetime DEFAULT NULL,
  `end_date` varchar(200) DEFAULT NULL,
  `rental_duration_hours` int(11) DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT NULL,
  `bike_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `Status` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`rental_id`),
  KEY `bike_id` (`bike_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rental_status`
--

DROP TABLE IF EXISTS `rental_status`;
CREATE TABLE IF NOT EXISTS `rental_status` (
  `bike_id` int(11) NOT NULL,
  `rental_start_time` datetime NOT NULL,
  `is_available` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`bike_id`,`rental_start_time`),
  KEY `rental_start_time` (`rental_start_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
