
 <?php

include('security.php');
if(isset($_POST['login_btn']))
{
    $email_login = mysqli_real_escape_string($connection,$_POST['username']); 
    $password_login = mysqli_real_escape_string($connection,$_POST['passwordd']); 

    $log_query = "SELECT * FROM customers WHERE binary username='$email_login' AND password='$password_login' LIMIT 1";
    $log_query_run = mysqli_query($connection, $log_query);
    if(mysqli_num_rows($log_query_run) > 0)
    {
        foreach($log_query_run as $row){
            $user_id =$row['customer_id'];
            $username =$row['username'];
            $user_email =$row['email'];
            $usertype =$row['usertype'];
           
        }
        $_SESSION['auth'] = "$usertype";
        $_SESSION['auth_user'] =[
           'user_id'=>$user_id,
           'username'=>$username,
           'user_email'=>$user_email,
        ];

        $_SESSION['status'] = "Welcome To XYZ";
         $_SESSION['status_code'] = "success";
        header('Location: Admin/index.php');
    }
    else
    {
        $_SESSION['status'] = "User Name & Password is Invalid";
        $_SESSION['status_code'] = "warning";
       header('Location:login.php');
    }

}
if(isset($_POST['add_user']))
{
            $fist_name = $_POST['fist_name'];
            $last_name = $_POST['last_name'];
            $email = $_POST['email'];
            $username = $_POST['username'];
            $phone = $_POST['phone'];
            $password = $_POST['password'];
            $address = $_POST['address'];
            $dob = $_POST['dob'];
           
        $query= "INSERT INTO `customers`(`username`, `first_name`, `last_name`, `email`, `phone_number`, `date_of_birth`, `Addresh`, `password`, `usertype`) VALUES ('$username','$fist_name','$last_name','$email','$phone','$dob','$address','$password','user')";
           $query_run = mysqli_query($connection, $query);
       
           if($query_run)
           { 
              
               $_SESSION['status'] = "User Add Successfull";
               $_SESSION['status_code'] = "success";
               header('Location: register.php'); 
           }
           else
           {
               $_SESSION['status'] = "Oops Somthing Went Worng!";
               $_SESSION['status_code'] = "error";
               header('Location: register.php'); 
   }   
 
}

?>



