<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Rentaly - Multipurpose Vehicle Car Rental Website Template</title>
    <link rel="icon" href="images/icon.png" type="image/gif" sizes="16x16">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Rentaly - Multipurpose Vehicle Car Rental Website Template" name="description">
    <meta content="" name="keywords">
    <meta content="" name="author">
    <!-- CSS Files
    ================================================== -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap">
    <link href="css/mdb.min.css" rel="stylesheet" type="text/css" id="mdb">
    <link href="css/plugins.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/coloring.css" rel="stylesheet" type="text/css">
    <!-- color scheme -->
    <link id="colors" href="css/colors/scheme-01.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="wrapper">
        
        <!-- page preloader begin -->
        <div id="de-preloader"></div>
        <!-- page preloader close -->

        <!-- header begin -->
        <header class="transparent scroll-light has-topbar">
            <div id="topbar" class="topbar-dark text-light">
                <div class="container">
                    <div class="topbar-left xs-hide">
                        <div class="topbar-widget">
                            <div class="topbar-widget"><a href="#"><i class="fa fa-phone"></i>+208 333 9296</a></div>
                            <div class="topbar-widget"><a href="#"><i class="fa fa-envelope"></i>contact@rentaly.com</a></div>
                            <div class="topbar-widget"><a href="#"><i class="fa fa-clock-o"></i>Mon - Fri 08.00 - 18.00</a></div>
                        </div>
                    </div>
                
                    <div class="topbar-right">
                        <div class="social-icons">
                            <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                            <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                            <a href="#"><i class="fa fa-youtube fa-lg"></i></a>
                            <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                            <a href="#"><i class="fa fa-instagram fa-lg"></i></a>
                        </div>
                    </div>  
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="de-flex sm-pt10">
                            <div class="de-flex-col">
                                <div class="de-flex-col">
                                    <!-- logo begin -->
                                    <div id="logo">
                                        <a href="index.html">
                                            <img class="logo-1" src="images/logo-light.png" alt="">
                                            <img class="logo-2" src="images/logo.png" alt="">
                                        </a>
                                    </div>
                                    <!-- logo close -->
                                </div>
                            </div>
                            <div class="de-flex-col header-col-mid">
                                <ul id="mainmenu">
                                    <li><a class="menu-item" href="index.html">Home</a>
                                        <ul>
                                            <li><a class="menu-item" href="index.html">Homepage 1</a></li>
                                            <li><a class="menu-item" href="index-2.html">Homepage 2</a></li>
                                            <li><a class="menu-item" href="index-3.html">Homepage 3</a></li>
                                            <li><a class="menu-item" href="index-4.html">Homepage 4</a></li>
                                            <li><a class="menu-item" href="index-5.html">Homepage 5</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="cars.html">Cars</a>
                                        <ul>
                                            <li><a class="menu-item" href="cars.html">Cars List 1</a></li>
                                            <li><a class="menu-item" href="cars-list.html">Cars List 2</a></li>
                                            <li><a class="menu-item" href="car-single.html">Cars Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="booking.html">Booking</a></li>
                                    <li><a class="menu-item" href="cars.html">My Account</a>
                                        <ul>
                                            <li><a class="menu-item" href="account-dashboard.html">Dashboard</a></li>
                                            <li><a class="menu-item" href="account-profile.html">My Profile</a></li>
                                            <li><a class="menu-item" href="account-booking.html">My Orders</a></li>
                                            <li><a class="menu-item" href="account-favorite.html">My Favorite Cars</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">Pages</a>
                                        <ul>
                                            <li><a class="menu-item" href="about.html">About Us</a></li>
                                            <li><a class="menu-item" href="contact.html">Contact</a></li>
                                            <li><a class="menu-item" href="login.html">Login</a></li>
                                            <li><a class="menu-item" href="register.html">Register</a></li>
                                            <li><a class="menu-item" href="404.html">Page 404</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">News</a>
                                        <ul>
                                            <li><a class="menu-item" href="news-standart-right-sidebar.html">News Standard</a>
                                                <ul>
                                                    <li><a class="menu-item" href="news-standart-right-sidebar.html">Right Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-standart-left-sidebar.html">Left Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-standart-no-sidebar.html">No Sidebar</a></li>
                                                </ul>
                                            </li>
                                            <li><a class="menu-item" href="news-grid-right-sidebar.html">News Grid</a>
                                                <ul>
                                                    <li><a class="menu-item" href="news-grid-right-sidebar.html">Right Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-grid-left-sidebar.html">Left Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-grid-no-sidebar.html">No Sidebar</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">Elements</a>
                                        <ul>
                                            <li><a class="menu-item" href="icon-boxes.html">Icon Boxes</a></li>
                                            <li><a class="menu-item" href="badge.html">Badge</a></li>
                                            <li><a class="menu-item" href="counters.html">Counters</a></li>
                                            <li><a class="menu-item" href="gallery-popup.html">Gallery Popup</a></li>
                                            <li><a class="menu-item" href="icons-elegant.html">Icons Elegant</a></li>
                                            <li><a class="menu-item" href="icons-etline.html">Icons Etline</a></li>
                                            <li><a class="menu-item" href="icons-font-awesome.html">Icons Font Awesome</a></li>
                                            <li><a class="menu-item" href="map.html">Map</a></li>
                                            <li><a class="menu-item" href="modal.html">Modal</a></li>
                                            <li><a class="menu-item" href="popover.html">Popover</a></li>
                                            <li><a class="menu-item" href="tabs.html">Tabs</a></li>
                                            <li><a class="menu-item" href="tooltips.html">Tooltips</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="de-flex-col">
                                <div class="menu_side_area">
                                    <a href="login.html" class="btn-main">Sign In</a>
                                    <span id="menu-btn"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
            <!-- header close -->
        <!-- content begin -->
        <div class="no-bottom no-top zebra" id="content">
            <div id="top"></div>
            
            <!-- section begin -->
            <section id="subheader" class="jarallax text-light">
                <img src="images/background/subheader.jpg" class="jarallax-img" alt="">
                    <div class="center-y relative text-center">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 text-center">
									<h1>Icon Boxes</h1>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
            </section>
            <!-- section close -->

            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <i class="fa fa-arrows-alt de-icon mb20"></i>
                            <h4>Responsive Layouts</h4>
                            <p>Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                        </div>
                        <div class="col-md-3">
                            <i class="fa fa-microchip de-icon mb20"></i>
                            <h4>Solid Framework</h4>
                            <p>Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                        </div>
                        <div class="col-md-3">
                            <i class="fa fa-trophy de-icon mb20"></i>
                            <h4>Top Selling Product</h4>
                            <p>Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                        </div>
                        <div class="col-md-3">
                            <i class="fa fa-paint-brush de-icon mb20"></i>
                            <h4>Easy to Customize</h4>
                            <p>Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="de-icon-box">
                                <i class="fa fa-arrows-alt de-icon mb20"></i>
                                <h4>Responsive Layouts</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="de-icon-box">
                                <i class="fa fa-microchip de-icon d-circle mb20"></i>
                                <h4>Solid Framework</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="de-icon-box">
                                <i class="fa fa-trophy de-icon mb20"></i>
                                <h4>Top Selling Product</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="de-icon-box">
                                <i class="fa fa-paint-brush de-icon d-circle mb20"></i>
                                <h4>Easy to Customize</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth" href="#">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="de-icon-box bg-color-secondary text-light">
                                <i class="fa fa-arrows-alt de-icon mb20"></i>
                                <h4>Responsive Layouts</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth btn-white" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="de-icon-box bg-color text-light">
                                <i class="fa fa-microchip de-icon d-circle bg-color-secondary mb20"></i>
                                <h4>Solid Framework</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth btn-white" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="de-icon-box bg-color-secondary text-light">
                                <i class="fa fa-trophy de-icon mb20"></i>
                                <h4>Top Selling Product</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth btn-white" href="#">Read more</a>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="de-icon-box bg-color text-light">
                                <i class="fa fa-paint-brush de-icon bg-color-secondary d-circle mb20"></i>
                                <h4>Easy to Customize</h4>
                                <p class="mb-3">Aliquip consequat excepteur non dolor irure ad irure labore ex eiusmod est duis culpa ex ut minim ut ea.</p>
                                <a class="btn-main btn-fullwidth btn-white" href="#">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
			
            <section>
                <div class="container">
                    <div class="row">

                        <div class="col-md-3 wow fadeInRight" data-wow-delay=".2s" >
                            <div class="feature-box style-4 text-center">
                                <a href="#"><i class="bg-color text-light i-boxed fa fa-arrows-alt"></i></a>
                                <div class="text">
                                    <a href="#"><h4>Responsive Layouts</h4></a>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                                </div>
                                <span class="wm">1</span>
                            </div>
                        </div>

                        <div class="col-md-3 wow fadeInRight" data-wow-delay=".4s" >
                            <div class="feature-box style-4 text-center">
                                <a href="#"><i class="bg-color text-light i-boxed fa fa-microchip"></i></a>
                                <div class="text">
                                    <a href="#"><h4>Solid Framework</h4></a>
                                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla


                                </div>
                                <span class="wm">2</span>
                            </div>
                        </div>

                        <div class="col-md-3 wow fadeInRight" data-wow-delay=".6s" >
                            <div class="feature-box style-4 text-center">
                                <a href="#"><i class="bg-color text-light i-boxed fa fa-trophy"></i></a>
                                <div class="text">
                                    <a href="#"><h4>Top Selling Product</h4></a>
                                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                </div>
                                <span class="wm">3</span>
                            </div>
                        </div>

                        <div class="col-md-3 wow fadeInRight" data-wow-delay=".6s" >
                            <div class="feature-box style-4 text-center">
                                <a href="#"><i class="bg-color text-light i-boxed fa fa-paint-brush"></i></a>
                                <div class="text">
                                    <a href="#"><h4>Easy to Customize</h4></a>
                                    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo


                                </div>
                                <span class="wm">3</span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="clearfix"></div>
                        <div class="col-lg-3">
                            <div class="box-icon s2 p-small mb20 wow fadeInRight" data-wow-delay=".5s">
                                <i class="fa bg-color fa-arrows-alt"></i>
                                <div class="d-inner">
                                    <h4>Respinsive Layouts</h4>
                                    Est dolore ut laboris eu enim eu veniam nostrud esse laborum duis consequat nostrud id
                                </div>
                            </div>
                            <div class="box-icon s2 p-small mb20 wow fadeInL fadeInRight" data-wow-delay=".75s">
                                <i class="fa bg-color fa-microchip"></i>
                                <div class="d-inner">
                                    <h4>Solid Framework</h4>
                                     Est dolore ut laboris eu enim eu veniam nostrud esse laborum duis consequat nostrud id
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <img src="images/misc/car.png" alt="" class="img-fluid wow fadeInUp">
                        </div>

                        <div class="col-lg-3">
                            <div class="box-icon s2 d-invert p-small mb20 wow fadeInL fadeInLeft" data-wow-delay="1s">
                                <i class="fa bg-color fa-trophy"></i>
                                <div class="d-inner">
                                    <h4>Top Selling Product</h4>
                                     Est dolore ut laboris eu enim eu veniam nostrud esse laborum duis consequat nostrud id
                                </div>
                            </div>
                            <div class="box-icon s2 d-invert p-small mb20 wow fadeInL fadeInLeft" data-wow-delay="1.25s">
                                <i class="fa bg-color fa-paint-brush"></i>
                                <div class="d-inner">
                                    <h4>Easy to Customize</h4>
                                     Est dolore ut laboris eu enim eu veniam nostrud esse laborum duis consequat nostrud id
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <div class="container">
                    <div class="row g-custom-x">
                        <div class="col-lg-4 col-md-6 mb30">
                            <div class="d-card">
                                <i class="fa fa-arrows-alt"></i>
                                <div class="text">
                                    <h4>Responsive Layouts</h4>Adipisicing sed voluptate cillum minim dolore in cillum ut culpa do proident duis eu adipisicing ex eiusmod irure.
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb30">
                            <div class="d-card">
                                <i class="fa fa-microchip"></i>
                                <div class="text">
                                    <h4 class="">Solid Framework</h4>Adipisicing sed voluptate cillum minim dolore in cillum ut culpa do proident duis eu adipisicing ex eiusmod irure.
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb30">
                            <div class="d-card">
                                <i class="fa fa-trophy"></i>
                                <div class="text">
                                    <h4>Top Selling Product</h4>Adipisicing sed voluptate cillum minim dolore in cillum ut culpa do proident duis eu adipisicing ex eiusmod irure.
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
			
        </div>
        <!-- content close -->

        <a href="#" id="back-to-top"></a>
        
        <!-- footer begin -->
        <footer class="text-light">
            <div class="container">
                <div class="row g-custom-x">
                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>About Rentaly</h5>
                            <p>In tempor magna non ut labore sunt et in adipisicing do in proident veniam officia deserunt mollit velit aliquip sint fugiat reprehenderit sint anim pariatur deserunt id in ut non.</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>Contact Info</h5>
                            <address class="s1">
                                <span><i class="id-color fa fa-map-marker fa-lg"></i>08 W 36th St, New York, NY 10001</span>
                                <span><i class="id-color fa fa-phone fa-lg"></i>+1 333 9296</span>
                                <span><i class="id-color fa fa-envelope-o fa-lg"></i><a href="mailto:contact@example.com">contact@example.com</a></span>
                                <span><i class="id-color fa fa-file-pdf-o fa-lg"></i><a href="#">Download Brochure</a></span>
                            </address>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <h5>Quick Links</h5>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="widget">
                                    <ul>
                                        <li><a href="#">About</a></li>
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">Careers</a></li>
                                        <li><a href="#">News</a></li>
                                        <li><a href="#">Partners</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>Social Network</h5>
                            <div class="social-icons">
                                <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                <a href="#"><i class="fa fa-rss fa-lg"></i></a>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
            <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="de-flex">
                                <div class="de-flex-col">
                                    <a href="index.html">
                                        Copyright 2023 - Rentaly by Designesia
                                    </a>
                                </div>
                                <ul class="menu-simple">
                                    <li><a href="#">Terms &amp; Conditions</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer close -->
        
    </div>


    <!-- Javascript Files
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/designesia.js"></script>

</body>

</html>