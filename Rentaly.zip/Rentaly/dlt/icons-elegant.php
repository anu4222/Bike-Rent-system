<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Rentaly - Multipurpose Vehicle Car Rental Website Template</title>
    <link rel="icon" href="images/icon.png" type="image/gif" sizes="16x16">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Rentaly - Multipurpose Vehicle Car Rental Website Template" name="description">
    <meta content="" name="keywords">
    <meta content="" name="author">
    <!-- CSS Files
    ================================================== -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap">
    <link href="css/mdb.min.css" rel="stylesheet" type="text/css" id="mdb">
    <link href="css/plugins.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/coloring.css" rel="stylesheet" type="text/css">
    <!-- color scheme -->
    <link id="colors" href="css/colors/scheme-01.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="wrapper">
        
        <!-- page preloader begin -->
        <div id="de-preloader"></div>
        <!-- page preloader close -->

        <!-- header begin -->
        <header class="transparent scroll-light has-topbar">
            <div id="topbar" class="topbar-dark text-light">
                <div class="container">
                    <div class="topbar-left xs-hide">
                        <div class="topbar-widget">
                            <div class="topbar-widget"><a href="#"><i class="fa fa-phone"></i>+208 333 9296</a></div>
                            <div class="topbar-widget"><a href="#"><i class="fa fa-envelope"></i>contact@rentaly.com</a></div>
                            <div class="topbar-widget"><a href="#"><i class="fa fa-clock-o"></i>Mon - Fri 08.00 - 18.00</a></div>
                        </div>
                    </div>
                
                    <div class="topbar-right">
                        <div class="social-icons">
                            <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                            <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                            <a href="#"><i class="fa fa-youtube fa-lg"></i></a>
                            <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                            <a href="#"><i class="fa fa-instagram fa-lg"></i></a>
                        </div>
                    </div>  
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="de-flex sm-pt10">
                            <div class="de-flex-col">
                                <div class="de-flex-col">
                                    <!-- logo begin -->
                                    <div id="logo">
                                        <a href="index.html">
                                            <img class="logo-1" src="images/logo-light.png" alt="">
                                            <img class="logo-2" src="images/logo.png" alt="">
                                        </a>
                                    </div>
                                    <!-- logo close -->
                                </div>
                            </div>
                            <div class="de-flex-col header-col-mid">
                                <ul id="mainmenu">
                                    <li><a class="menu-item" href="index.html">Home</a>
                                        <ul>
                                            <li><a class="menu-item" href="index.html">Homepage 1</a></li>
                                            <li><a class="menu-item" href="index-2.html">Homepage 2</a></li>
                                            <li><a class="menu-item" href="index-3.html">Homepage 3</a></li>
                                            <li><a class="menu-item" href="index-4.html">Homepage 4</a></li>
                                            <li><a class="menu-item" href="index-5.html">Homepage 5</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="cars.html">Cars</a>
                                        <ul>
                                            <li><a class="menu-item" href="cars.html">Cars List 1</a></li>
                                            <li><a class="menu-item" href="cars-list.html">Cars List 2</a></li>
                                            <li><a class="menu-item" href="car-single.html">Cars Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="booking.html">Booking</a></li>
                                    <li><a class="menu-item" href="cars.html">My Account</a>
                                        <ul>
                                            <li><a class="menu-item" href="account-dashboard.html">Dashboard</a></li>
                                            <li><a class="menu-item" href="account-profile.html">My Profile</a></li>
                                            <li><a class="menu-item" href="account-booking.html">My Orders</a></li>
                                            <li><a class="menu-item" href="account-favorite.html">My Favorite Cars</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">Pages</a>
                                        <ul>
                                            <li><a class="menu-item" href="about.html">About Us</a></li>
                                            <li><a class="menu-item" href="contact.html">Contact</a></li>
                                            <li><a class="menu-item" href="login.html">Login</a></li>
                                            <li><a class="menu-item" href="register.html">Register</a></li>
                                            <li><a class="menu-item" href="404.html">Page 404</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">News</a>
                                        <ul>
                                            <li><a class="menu-item" href="news-standart-right-sidebar.html">News Standard</a>
                                                <ul>
                                                    <li><a class="menu-item" href="news-standart-right-sidebar.html">Right Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-standart-left-sidebar.html">Left Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-standart-no-sidebar.html">No Sidebar</a></li>
                                                </ul>
                                            </li>
                                            <li><a class="menu-item" href="news-grid-right-sidebar.html">News Grid</a>
                                                <ul>
                                                    <li><a class="menu-item" href="news-grid-right-sidebar.html">Right Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-grid-left-sidebar.html">Left Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-grid-no-sidebar.html">No Sidebar</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">Elements</a>
                                        <ul>
                                            <li><a class="menu-item" href="icon-boxes.html">Icon Boxes</a></li>
                                            <li><a class="menu-item" href="badge.html">Badge</a></li>
                                            <li><a class="menu-item" href="counters.html">Counters</a></li>
                                            <li><a class="menu-item" href="gallery-popup.html">Gallery Popup</a></li>
                                            <li><a class="menu-item" href="icons-elegant.html">Icons Elegant</a></li>
                                            <li><a class="menu-item" href="icons-etline.html">Icons Etline</a></li>
                                            <li><a class="menu-item" href="icons-font-awesome.html">Icons Font Awesome</a></li>
                                            <li><a class="menu-item" href="map.html">Map</a></li>
                                            <li><a class="menu-item" href="modal.html">Modal</a></li>
                                            <li><a class="menu-item" href="popover.html">Popover</a></li>
                                            <li><a class="menu-item" href="tabs.html">Tabs</a></li>
                                            <li><a class="menu-item" href="tooltips.html">Tooltips</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="de-flex-col">
                                <div class="menu_side_area">
                                    <a href="login.html" class="btn-main">Sign In</a>
                                    <span id="menu-btn"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
            <!-- header close -->
        <!-- content begin -->
        <div class="no-bottom no-top" id="content">
            <div id="top"></div>
            
            <!-- section begin -->
            <section id="subheader" class="jarallax text-light">
                <img src="images/background/subheader.jpg" class="jarallax-img" alt="">
                    <div class="center-y relative text-center">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 text-center">
									<h1>Elegant Icons</h1>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
            </section>
            <!-- section close -->
            

            <!-- section begin -->
            <section aria-label="section">
                <div class="container">
					<div class="row">
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_up"></span> &nbsp;arrow_up
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_down"></span> &nbsp;arrow_down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left"></span> &nbsp;arrow_left
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_right"></span> &nbsp;arrow_right
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left-up"></span> &nbsp;arrow_left-up
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_right-up"></span> &nbsp;arrow_right-up
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_right-down"></span> &nbsp;arrow_right-down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left-down"></span> &nbsp;arrow_left-down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow-up-down"></span> &nbsp;arrow-up-down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_up-down_alt"></span> &nbsp;arrow_up-down_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left-right_alt"></span> &nbsp;arrow_left-right_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left-right"></span> &nbsp;arrow_left-right
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_expand_alt2"></span> &nbsp;arrow_expand_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_expand_alt"></span> &nbsp;arrow_expand_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_condense"></span> &nbsp;arrow_condense
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_expand"></span> &nbsp;arrow_expand
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_move"></span> &nbsp;arrow_move
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-up"></span> &nbsp;arrow_carrot-up
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-down"></span> &nbsp;arrow_carrot-down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-left"></span> &nbsp;arrow_carrot-left
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-right"></span> &nbsp;arrow_carrot-right
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2up"></span> &nbsp;arrow_carrot-2up
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2down"></span> &nbsp;arrow_carrot-2down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2left"></span> &nbsp;arrow_carrot-2left
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2right"></span> &nbsp;arrow_carrot-2right
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-up_alt2"></span> &nbsp;arrow_carrot-up_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-down_alt2"></span> &nbsp;arrow_carrot-down_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-left_alt2"></span> &nbsp;arrow_carrot-left_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-right_alt2"></span> &nbsp;arrow_carrot-right_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2up_alt2"></span> &nbsp;arrow_carrot-2up_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2down_alt2"></span> &nbsp;arrow_carrot-2down_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2left_alt2"></span> &nbsp;arrow_carrot-2left_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2right_alt2"></span> &nbsp;arrow_carrot-2right_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-up"></span> &nbsp;arrow_triangle-up
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-down"></span> &nbsp;arrow_triangle-down
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-left"></span> &nbsp;arrow_triangle-left
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-right"></span> &nbsp;arrow_triangle-right
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-up_alt2"></span> &nbsp;arrow_triangle-up_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-down_alt2"></span> &nbsp;arrow_triangle-down_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-left_alt2"></span> &nbsp;arrow_triangle-left_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-right_alt2"></span> &nbsp;arrow_triangle-right_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_back"></span> &nbsp;arrow_back
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_minus-06"></span> &nbsp;icon_minus-06
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_plus"></span> &nbsp;icon_plus
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_close"></span> &nbsp;icon_close
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_check"></span> &nbsp;icon_check
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_minus_alt2"></span> &nbsp;icon_minus_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_plus_alt2"></span> &nbsp;icon_plus_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_close_alt2"></span> &nbsp;icon_close_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_check_alt2"></span> &nbsp;icon_check_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_zoom-out_alt"></span> &nbsp;icon_zoom-out_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_zoom-in_alt"></span> &nbsp;icon_zoom-in_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_search"></span> &nbsp;icon_search
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_box-empty"></span> &nbsp;icon_box-empty
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_box-selected"></span> &nbsp;icon_box-selected
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_minus-box"></span> &nbsp;icon_minus-box
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_plus-box"></span> &nbsp;icon_plus-box
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_box-checked"></span> &nbsp;icon_box-checked
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_circle-empty"></span> &nbsp;icon_circle-empty
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_circle-slelected"></span> &nbsp;icon_circle-slelected
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_stop_alt2"></span> &nbsp;icon_stop_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_stop"></span> &nbsp;icon_stop
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pause_alt2"></span> &nbsp;icon_pause_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pause"></span> &nbsp;icon_pause
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_menu"></span> &nbsp;icon_menu
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_menu-square_alt2"></span> &nbsp;icon_menu-square_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_menu-circle_alt2"></span> &nbsp;icon_menu-circle_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_ul"></span> &nbsp;icon_ul
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_ol"></span> &nbsp;icon_ol
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_adjust-horiz"></span> &nbsp;icon_adjust-horiz
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_adjust-vert"></span> &nbsp;icon_adjust-vert
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_document_alt"></span> &nbsp;icon_document_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_documents_alt"></span> &nbsp;icon_documents_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pencil"></span> &nbsp;icon_pencil
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pencil-edit_alt"></span> &nbsp;icon_pencil-edit_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pencil-edit"></span> &nbsp;icon_pencil-edit
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder-alt"></span> &nbsp;icon_folder-alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder-open_alt"></span> &nbsp;icon_folder-open_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder-add_alt"></span> &nbsp;icon_folder-add_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_info_alt"></span> &nbsp;icon_info_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_error-oct_alt"></span> &nbsp;icon_error-oct_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_error-circle_alt"></span> &nbsp;icon_error-circle_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_error-triangle_alt"></span> &nbsp;icon_error-triangle_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_question_alt2"></span> &nbsp;icon_question_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_question"></span> &nbsp;icon_question
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_comment_alt"></span> &nbsp;icon_comment_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_chat_alt"></span> &nbsp;icon_chat_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_vol-mute_alt"></span> &nbsp;icon_vol-mute_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_volume-low_alt"></span> &nbsp;icon_volume-low_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_volume-high_alt"></span> &nbsp;icon_volume-high_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_quotations"></span> &nbsp;icon_quotations
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_quotations_alt2"></span> &nbsp;icon_quotations_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_clock_alt"></span> &nbsp;icon_clock_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lock_alt"></span> &nbsp;icon_lock_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lock-open_alt"></span> &nbsp;icon_lock-open_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_key_alt"></span> &nbsp;icon_key_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cloud_alt"></span> &nbsp;icon_cloud_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cloud-upload_alt"></span> &nbsp;icon_cloud-upload_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cloud-download_alt"></span> &nbsp;icon_cloud-download_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_image"></span> &nbsp;icon_image
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_images"></span> &nbsp;icon_images
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lightbulb_alt"></span> &nbsp;icon_lightbulb_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_gift_alt"></span> &nbsp;icon_gift_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_house_alt"></span> &nbsp;icon_house_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_genius"></span> &nbsp;icon_genius
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mobile"></span> &nbsp;icon_mobile
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tablet"></span> &nbsp;icon_tablet
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_laptop"></span> &nbsp;icon_laptop
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_desktop"></span> &nbsp;icon_desktop
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_camera_alt"></span> &nbsp;icon_camera_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mail_alt"></span> &nbsp;icon_mail_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cone_alt"></span> &nbsp;icon_cone_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_ribbon_alt"></span> &nbsp;icon_ribbon_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_bag_alt"></span> &nbsp;icon_bag_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_creditcard"></span> &nbsp;icon_creditcard
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cart_alt"></span> &nbsp;icon_cart_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_paperclip"></span> &nbsp;icon_paperclip
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tag_alt"></span> &nbsp;icon_tag_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tags_alt"></span> &nbsp;icon_tags_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_trash_alt"></span> &nbsp;icon_trash_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cursor_alt"></span> &nbsp;icon_cursor_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mic_alt"></span> &nbsp;icon_mic_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_compass_alt"></span> &nbsp;icon_compass_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pin_alt"></span> &nbsp;icon_pin_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pushpin_alt"></span> &nbsp;icon_pushpin_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_map_alt"></span> &nbsp;icon_map_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_drawer_alt"></span> &nbsp;icon_drawer_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_toolbox_alt"></span> &nbsp;icon_toolbox_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_book_alt"></span> &nbsp;icon_book_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_calendar"></span> &nbsp;icon_calendar
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_film"></span> &nbsp;icon_film
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_table"></span> &nbsp;icon_table
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_contacts_alt"></span> &nbsp;icon_contacts_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_headphones"></span> &nbsp;icon_headphones
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lifesaver"></span> &nbsp;icon_lifesaver
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_piechart"></span> &nbsp;icon_piechart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_refresh"></span> &nbsp;icon_refresh
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_link_alt"></span> &nbsp;icon_link_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_link"></span> &nbsp;icon_link
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_loading"></span> &nbsp;icon_loading
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_blocked"></span> &nbsp;icon_blocked
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_archive_alt"></span> &nbsp;icon_archive_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_heart_alt"></span> &nbsp;icon_heart_alt
						</div>

						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_printer"></span> &nbsp;icon_printer
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_calulator"></span> &nbsp;icon_calulator
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_building"></span> &nbsp;icon_building
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_floppy"></span> &nbsp;icon_floppy
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_drive"></span> &nbsp;icon_drive
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_search-2"></span> &nbsp;icon_search-2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_id"></span> &nbsp;icon_id
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_id-2"></span> &nbsp;icon_id-2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_puzzle"></span> &nbsp;icon_puzzle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_like"></span> &nbsp;icon_like
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_dislike"></span> &nbsp;icon_dislike
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mug"></span> &nbsp;icon_mug
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_currency"></span> &nbsp;icon_currency
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_wallet"></span> &nbsp;icon_wallet
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pens"></span> &nbsp;icon_pens
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_easel"></span> &nbsp;icon_easel
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_flowchart"></span> &nbsp;icon_flowchart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_datareport"></span> &nbsp;icon_datareport
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_briefcase"></span> &nbsp;icon_briefcase
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_shield"></span> &nbsp;icon_shield
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_percent"></span> &nbsp;icon_percent
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_globe"></span> &nbsp;icon_globe
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_globe-2"></span> &nbsp;icon_globe-2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_target"></span> &nbsp;icon_target
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_hourglass"></span> &nbsp;icon_hourglass
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_balance"></span> &nbsp;icon_balance
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_star_alt"></span> &nbsp;icon_star_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_star-half_alt"></span> &nbsp;icon_star-half_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_star"></span> &nbsp;icon_star
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_star-half"></span> &nbsp;icon_star-half
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tools"></span> &nbsp;icon_tools
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tool"></span> &nbsp;icon_tool
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cog"></span> &nbsp;icon_cog
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cogs"></span> &nbsp;icon_cogs
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_up_alt"></span> &nbsp;arrow_up_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_down_alt"></span> &nbsp;arrow_down_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left_alt"></span> &nbsp;arrow_left_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_right_alt"></span> &nbsp;arrow_right_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left-up_alt"></span> &nbsp;arrow_left-up_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_right-up_alt"></span> &nbsp;arrow_right-up_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_right-down_alt"></span> &nbsp;arrow_right-down_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_left-down_alt"></span> &nbsp;arrow_left-down_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_condense_alt"></span> &nbsp;arrow_condense_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_expand_alt3"></span> &nbsp;arrow_expand_alt3
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot_up_alt"></span> &nbsp;arrow_carrot_up_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-down_alt"></span> &nbsp;arrow_carrot-down_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-left_alt"></span> &nbsp;arrow_carrot-left_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-right_alt"></span> &nbsp;arrow_carrot-right_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2up_alt"></span> &nbsp;arrow_carrot-2up_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2dwnn_alt"></span> &nbsp;arrow_carrot-2dwnn_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2left_alt"></span> &nbsp;arrow_carrot-2left_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_carrot-2right_alt"></span> &nbsp;arrow_carrot-2right_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-up_alt"></span> &nbsp;arrow_triangle-up_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-down_alt"></span> &nbsp;arrow_triangle-down_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-left_alt"></span> &nbsp;arrow_triangle-left_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="arrow_triangle-right_alt"></span> &nbsp;arrow_triangle-right_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_minus_alt"></span> &nbsp;icon_minus_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_plus_alt"></span> &nbsp;icon_plus_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_close_alt"></span> &nbsp;icon_close_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_check_alt"></span> &nbsp;icon_check_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_zoom-out"></span> &nbsp;icon_zoom-out
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_zoom-in"></span> &nbsp;icon_zoom-in
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_stop_alt"></span> &nbsp;icon_stop_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_menu-square_alt"></span> &nbsp;icon_menu-square_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_menu-circle_alt"></span> &nbsp;icon_menu-circle_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_document"></span> &nbsp;icon_document
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_documents"></span> &nbsp;icon_documents
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pencil_alt"></span> &nbsp;icon_pencil_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder"></span> &nbsp;icon_folder
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder-open"></span> &nbsp;icon_folder-open
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder-add"></span> &nbsp;icon_folder-add
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder_upload"></span> &nbsp;icon_folder_upload
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_folder_download"></span> &nbsp;icon_folder_download
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_info"></span> &nbsp;icon_info
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_error-circle"></span> &nbsp;icon_error-circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_error-oct"></span> &nbsp;icon_error-oct
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_error-triangle"></span> &nbsp;icon_error-triangle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_question_alt"></span> &nbsp;icon_question_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_comment"></span> &nbsp;icon_comment
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_chat"></span> &nbsp;icon_chat
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_vol-mute"></span> &nbsp;icon_vol-mute
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_volume-low"></span> &nbsp;icon_volume-low
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_volume-high"></span> &nbsp;icon_volume-high
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_quotations_alt"></span> &nbsp;icon_quotations_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_clock"></span> &nbsp;icon_clock
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lock"></span> &nbsp;icon_lock
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lock-open"></span> &nbsp;icon_lock-open
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_key"></span> &nbsp;icon_key
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cloud"></span> &nbsp;icon_cloud
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cloud-upload"></span> &nbsp;icon_cloud-upload
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cloud-download"></span> &nbsp;icon_cloud-download
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_lightbulb"></span> &nbsp;icon_lightbulb
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_gift"></span> &nbsp;icon_gift
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_house"></span> &nbsp;icon_house
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_camera"></span> &nbsp;icon_camera
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mail"></span> &nbsp;icon_mail
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cone"></span> &nbsp;icon_cone
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_ribbon"></span> &nbsp;icon_ribbon
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_bag"></span> &nbsp;icon_bag
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cart"></span> &nbsp;icon_cart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tag"></span> &nbsp;icon_tag
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_tags"></span> &nbsp;icon_tags
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_trash"></span> &nbsp;icon_trash
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_cursor"></span> &nbsp;icon_cursor
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mic"></span> &nbsp;icon_mic
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_compass"></span> &nbsp;icon_compass
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pin"></span> &nbsp;icon_pin
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pushpin"></span> &nbsp;icon_pushpin
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_map"></span> &nbsp;icon_map
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_drawer"></span> &nbsp;icon_drawer
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_toolbox"></span> &nbsp;icon_toolbox
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_book"></span> &nbsp;icon_book
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_contacts"></span> &nbsp;icon_contacts
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_archive"></span> &nbsp;icon_archive
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_heart"></span> &nbsp;icon_heart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_profile"></span> &nbsp;icon_profile
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_group"></span> &nbsp;icon_group
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_grid-2x2"></span> &nbsp;icon_grid-2x2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_grid-3x3"></span> &nbsp;icon_grid-3x3
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_music"></span> &nbsp;icon_music
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pause_alt"></span> &nbsp;icon_pause_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_phone"></span> &nbsp;icon_phone
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_upload"></span> &nbsp;icon_upload
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_download"></span> &nbsp;icon_download
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_rook"></span> &nbsp;icon_rook
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_printer-alt"></span> &nbsp;icon_printer-alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_calculator_alt"></span> &nbsp;icon_calculator_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_building_alt"></span> &nbsp;icon_building_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_floppy_alt"></span> &nbsp;icon_floppy_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_drive_alt"></span> &nbsp;icon_drive_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_search_alt"></span> &nbsp;icon_search_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_id_alt"></span> &nbsp;icon_id_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_id-2_alt"></span> &nbsp;icon_id-2_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_puzzle_alt"></span> &nbsp;icon_puzzle_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_like_alt"></span> &nbsp;icon_like_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_dislike_alt"></span> &nbsp;icon_dislike_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_mug_alt"></span> &nbsp;icon_mug_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_currency_alt"></span> &nbsp;icon_currency_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_wallet_alt"></span> &nbsp;icon_wallet_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_pens_alt"></span> &nbsp;icon_pens_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_easel_alt"></span> &nbsp;icon_easel_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_flowchart_alt"></span> &nbsp;icon_flowchart_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_datareport_alt"></span> &nbsp;icon_datareport_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_briefcase_alt"></span> &nbsp;icon_briefcase_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_shield_alt"></span> &nbsp;icon_shield_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_percent_alt"></span> &nbsp;icon_percent_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_globe_alt"></span> &nbsp;icon_globe_alt
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon_clipboard"></span> &nbsp;icon_clipboard
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_facebook"></span> &nbsp;social_facebook
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_twitter"></span> &nbsp;social_twitter
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_pinterest"></span> &nbsp;social_pinterest
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_googleplus"></span> &nbsp;social_googleplus
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_tumblr"></span> &nbsp;social_tumblr
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_tumbleupon"></span> &nbsp;social_tumbleupon
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_wordpress"></span> &nbsp;social_wordpress
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_instagram"></span> &nbsp;social_instagram
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_dribbble"></span> &nbsp;social_dribbble
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_vimeo"></span> &nbsp;social_vimeo
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_linkedin"></span> &nbsp;social_linkedin
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_rss"></span> &nbsp;social_rss
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_deviantart"></span> &nbsp;social_deviantart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_share"></span> &nbsp;social_share
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_myspace"></span> &nbsp;social_myspace
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_skype"></span> &nbsp;social_skype
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_youtube"></span> &nbsp;social_youtube
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_picassa"></span> &nbsp;social_picassa
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_googledrive"></span> &nbsp;social_googledrive
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_flickr"></span> &nbsp;social_flickr
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_blogger"></span> &nbsp;social_blogger
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_spotify"></span> &nbsp;social_spotify
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_delicious"></span> &nbsp;social_delicious
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_facebook_circle"></span> &nbsp;social_facebook_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_twitter_circle"></span> &nbsp;social_twitter_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_pinterest_circle"></span> &nbsp;social_pinterest_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_googleplus_circle"></span> &nbsp;social_googleplus_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_tumblr_circle"></span> &nbsp;social_tumblr_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_stumbleupon_circle"></span> &nbsp;social_stumbleupon_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_wordpress_circle"></span> &nbsp;social_wordpress_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_instagram_circle"></span> &nbsp;social_instagram_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_dribbble_circle"></span> &nbsp;social_dribbble_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_vimeo_circle"></span> &nbsp;social_vimeo_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_linkedin_circle"></span> &nbsp;social_linkedin_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_rss_circle"></span> &nbsp;social_rss_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_deviantart_circle"></span> &nbsp;social_deviantart_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_share_circle"></span> &nbsp;social_share_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_myspace_circle"></span> &nbsp;social_myspace_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_skype_circle"></span> &nbsp;social_skype_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_youtube_circle"></span> &nbsp;social_youtube_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_picassa_circle"></span> &nbsp;social_picassa_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_googledrive_alt2"></span> &nbsp;social_googledrive_alt2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_flickr_circle"></span> &nbsp;social_flickr_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_blogger_circle"></span> &nbsp;social_blogger_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_spotify_circle"></span> &nbsp;social_spotify_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_delicious_circle"></span> &nbsp;social_delicious_circle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_facebook_square"></span> &nbsp;social_facebook_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_twitter_square"></span> &nbsp;social_twitter_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_pinterest_square"></span> &nbsp;social_pinterest_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_googleplus_square"></span> &nbsp;social_googleplus_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_tumblr_square"></span> &nbsp;social_tumblr_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_stumbleupon_square"></span> &nbsp;social_stumbleupon_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_wordpress_square"></span> &nbsp;social_wordpress_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_instagram_square"></span> &nbsp;social_instagram_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_dribbble_square"></span> &nbsp;social_dribbble_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_vimeo_square"></span> &nbsp;social_vimeo_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_linkedin_square"></span> &nbsp;social_linkedin_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_rss_square"></span> &nbsp;social_rss_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_deviantart_square"></span> &nbsp;social_deviantart_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_share_square"></span> &nbsp;social_share_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_myspace_square"></span> &nbsp;social_myspace_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_skype_square"></span> &nbsp;social_skype_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_youtube_square"></span> &nbsp;social_youtube_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_picassa_square"></span> &nbsp;social_picassa_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_googledrive_square"></span> &nbsp;social_googledrive_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_flickr_square"></span> &nbsp;social_flickr_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_blogger_square"></span> &nbsp;social_blogger_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_spotify_square"></span> &nbsp;social_spotify_square
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="social_delicious_square"></span> &nbsp;social_delicious_square
						</div>

					</div>
				</div>
            </section>
            <!-- section close -->

        </div>
        <!-- content close -->

        <a href="#" id="back-to-top"></a>
        
        <!-- footer begin -->
        <footer class="text-light">
            <div class="container">
                <div class="row g-custom-x">
                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>About Rentaly</h5>
                            <p>In tempor magna non ut labore sunt et in adipisicing do in proident veniam officia deserunt mollit velit aliquip sint fugiat reprehenderit sint anim pariatur deserunt id in ut non.</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>Contact Info</h5>
                            <address class="s1">
                                <span><i class="id-color fa fa-map-marker fa-lg"></i>08 W 36th St, New York, NY 10001</span>
                                <span><i class="id-color fa fa-phone fa-lg"></i>+1 333 9296</span>
                                <span><i class="id-color fa fa-envelope-o fa-lg"></i><a href="mailto:contact@example.com">contact@example.com</a></span>
                                <span><i class="id-color fa fa-file-pdf-o fa-lg"></i><a href="#">Download Brochure</a></span>
                            </address>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <h5>Quick Links</h5>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="widget">
                                    <ul>
                                        <li><a href="#">About</a></li>
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">Careers</a></li>
                                        <li><a href="#">News</a></li>
                                        <li><a href="#">Partners</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>Social Network</h5>
                            <div class="social-icons">
                                <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                <a href="#"><i class="fa fa-rss fa-lg"></i></a>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
            <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="de-flex">
                                <div class="de-flex-col">
                                    <a href="index.html">
                                        Copyright 2023 - Rentaly by Designesia
                                    </a>
                                </div>
                                <ul class="menu-simple">
                                    <li><a href="#">Terms &amp; Conditions</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer close -->
        
    </div>


    <!-- Javascript Files
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/designesia.js"></script>

</body>

</html>