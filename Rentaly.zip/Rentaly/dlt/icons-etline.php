<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Rentaly - Multipurpose Vehicle Car Rental Website Template</title>
    <link rel="icon" href="images/icon.png" type="image/gif" sizes="16x16">
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Rentaly - Multipurpose Vehicle Car Rental Website Template" name="description">
    <meta content="" name="keywords">
    <meta content="" name="author">
    <!-- CSS Files
    ================================================== -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap">
    <link href="css/mdb.min.css" rel="stylesheet" type="text/css" id="mdb">
    <link href="css/plugins.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/coloring.css" rel="stylesheet" type="text/css">
    <!-- color scheme -->
    <link id="colors" href="css/colors/scheme-01.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="wrapper">
        
        <!-- page preloader begin -->
        <div id="de-preloader"></div>
        <!-- page preloader close -->

        <!-- header begin -->
        <header class="transparent scroll-light has-topbar">
            <div id="topbar" class="topbar-dark text-light">
                <div class="container">
                    <div class="topbar-left xs-hide">
                        <div class="topbar-widget">
                            <div class="topbar-widget"><a href="#"><i class="fa fa-phone"></i>+208 333 9296</a></div>
                            <div class="topbar-widget"><a href="#"><i class="fa fa-envelope"></i>contact@rentaly.com</a></div>
                            <div class="topbar-widget"><a href="#"><i class="fa fa-clock-o"></i>Mon - Fri 08.00 - 18.00</a></div>
                        </div>
                    </div>
                
                    <div class="topbar-right">
                        <div class="social-icons">
                            <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                            <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                            <a href="#"><i class="fa fa-youtube fa-lg"></i></a>
                            <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                            <a href="#"><i class="fa fa-instagram fa-lg"></i></a>
                        </div>
                    </div>  
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="de-flex sm-pt10">
                            <div class="de-flex-col">
                                <div class="de-flex-col">
                                    <!-- logo begin -->
                                    <div id="logo">
                                        <a href="index.html">
                                            <img class="logo-1" src="images/logo-light.png" alt="">
                                            <img class="logo-2" src="images/logo.png" alt="">
                                        </a>
                                    </div>
                                    <!-- logo close -->
                                </div>
                            </div>
                            <div class="de-flex-col header-col-mid">
                                <ul id="mainmenu">
                                    <li><a class="menu-item" href="index.html">Home</a>
                                        <ul>
                                            <li><a class="menu-item" href="index.html">Homepage 1</a></li>
                                            <li><a class="menu-item" href="index-2.html">Homepage 2</a></li>
                                            <li><a class="menu-item" href="index-3.html">Homepage 3</a></li>
                                            <li><a class="menu-item" href="index-4.html">Homepage 4</a></li>
                                            <li><a class="menu-item" href="index-5.html">Homepage 5</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="cars.html">Cars</a>
                                        <ul>
                                            <li><a class="menu-item" href="cars.html">Cars List 1</a></li>
                                            <li><a class="menu-item" href="cars-list.html">Cars List 2</a></li>
                                            <li><a class="menu-item" href="car-single.html">Cars Single</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="booking.html">Booking</a></li>
                                    <li><a class="menu-item" href="cars.html">My Account</a>
                                        <ul>
                                            <li><a class="menu-item" href="account-dashboard.html">Dashboard</a></li>
                                            <li><a class="menu-item" href="account-profile.html">My Profile</a></li>
                                            <li><a class="menu-item" href="account-booking.html">My Orders</a></li>
                                            <li><a class="menu-item" href="account-favorite.html">My Favorite Cars</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">Pages</a>
                                        <ul>
                                            <li><a class="menu-item" href="about.html">About Us</a></li>
                                            <li><a class="menu-item" href="contact.html">Contact</a></li>
                                            <li><a class="menu-item" href="login.html">Login</a></li>
                                            <li><a class="menu-item" href="register.html">Register</a></li>
                                            <li><a class="menu-item" href="404.html">Page 404</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">News</a>
                                        <ul>
                                            <li><a class="menu-item" href="news-standart-right-sidebar.html">News Standard</a>
                                                <ul>
                                                    <li><a class="menu-item" href="news-standart-right-sidebar.html">Right Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-standart-left-sidebar.html">Left Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-standart-no-sidebar.html">No Sidebar</a></li>
                                                </ul>
                                            </li>
                                            <li><a class="menu-item" href="news-grid-right-sidebar.html">News Grid</a>
                                                <ul>
                                                    <li><a class="menu-item" href="news-grid-right-sidebar.html">Right Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-grid-left-sidebar.html">Left Sidebar</a></li>
                                                    <li><a class="menu-item" href="news-grid-no-sidebar.html">No Sidebar</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="menu-item" href="#">Elements</a>
                                        <ul>
                                            <li><a class="menu-item" href="icon-boxes.html">Icon Boxes</a></li>
                                            <li><a class="menu-item" href="badge.html">Badge</a></li>
                                            <li><a class="menu-item" href="counters.html">Counters</a></li>
                                            <li><a class="menu-item" href="gallery-popup.html">Gallery Popup</a></li>
                                            <li><a class="menu-item" href="icons-elegant.html">Icons Elegant</a></li>
                                            <li><a class="menu-item" href="icons-etline.html">Icons Etline</a></li>
                                            <li><a class="menu-item" href="icons-font-awesome.html">Icons Font Awesome</a></li>
                                            <li><a class="menu-item" href="map.html">Map</a></li>
                                            <li><a class="menu-item" href="modal.html">Modal</a></li>
                                            <li><a class="menu-item" href="popover.html">Popover</a></li>
                                            <li><a class="menu-item" href="tabs.html">Tabs</a></li>
                                            <li><a class="menu-item" href="tooltips.html">Tooltips</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            <div class="de-flex-col">
                                <div class="menu_side_area">
                                    <a href="login.html" class="btn-main">Sign In</a>
                                    <span id="menu-btn"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
            <!-- header close -->
        <!-- content begin -->
        <div class="no-bottom no-top" id="content">
            <div id="top"></div>
            
            <!-- section begin -->
            <section id="subheader" class="jarallax text-light">
                <img src="images/background/subheader.jpg" class="jarallax-img" alt="">
                    <div class="center-y relative text-center">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 text-center">
									<h1>Etline Icons</h1>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
            </section>
            <!-- section close -->
            

            <!-- section begin -->
            <section aria-label="section">
                <div class="container">
					<div class="row">

						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-mobile"></span> &nbsp;icon-mobile
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-laptop"></span> &nbsp;icon-laptop
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-desktop"></span> &nbsp;icon-desktop
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-tablet"></span> &nbsp;icon-tablet
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-phone"></span> &nbsp;icon-phone
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-document"></span> &nbsp;icon-document
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-documents"></span> &nbsp;icon-documents
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-search"></span> &nbsp;icon-search
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-clipboard"></span> &nbsp;icon-clipboard
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-newspaper"></span> &nbsp;icon-newspaper
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-notebook"></span> &nbsp;icon-notebook
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-book-open"></span> &nbsp;icon-book-open
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-browser"></span> &nbsp;icon-browser
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-calendar"></span> &nbsp;icon-calendar
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-presentation"></span> &nbsp;icon-presentation
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-picture"></span> &nbsp;icon-picture
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-pictures"></span> &nbsp;icon-pictures
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-video"></span> &nbsp;icon-video
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-camera"></span> &nbsp;icon-camera
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-printer"></span> &nbsp;icon-printer
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-toolbox"></span> &nbsp;icon-toolbox
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-briefcase"></span> &nbsp;icon-briefcase
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-wallet"></span> &nbsp;icon-wallet
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-gift"></span> &nbsp;icon-gift
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-bargraph"></span> &nbsp;icon-bargraph
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-grid"></span> &nbsp;icon-grid
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-expand"></span> &nbsp;icon-expand
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-focus"></span> &nbsp;icon-focus
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-edit"></span> &nbsp;icon-edit
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-adjustments"></span> &nbsp;icon-adjustments
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-ribbon"></span> &nbsp;icon-ribbon
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-hourglass"></span> &nbsp;icon-hourglass
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-lock"></span> &nbsp;icon-lock
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-megaphone"></span> &nbsp;icon-megaphone
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-shield"></span> &nbsp;icon-shield
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-trophy"></span> &nbsp;icon-trophy
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-flag"></span> &nbsp;icon-flag
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-map"></span> &nbsp;icon-map
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-puzzle"></span> &nbsp;icon-puzzle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-basket"></span> &nbsp;icon-basket
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-envelope"></span> &nbsp;icon-envelope
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-streetsign"></span> &nbsp;icon-streetsign
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-telescope"></span> &nbsp;icon-telescope
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-gears"></span> &nbsp;icon-gears
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-key"></span> &nbsp;icon-key
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-paperclip"></span> &nbsp;icon-paperclip
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-attachment"></span> &nbsp;icon-attachment
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-pricetags"></span> &nbsp;icon-pricetags
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-lightbulb"></span> &nbsp;icon-lightbulb
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-layers"></span> &nbsp;icon-layers
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-pencil"></span> &nbsp;icon-pencil
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-tools"></span> &nbsp;icon-tools
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-tools-2"></span> &nbsp;icon-tools-2
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-scissors"></span> &nbsp;icon-scissors
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-paintbrush"></span> &nbsp;icon-paintbrush
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-magnifying-glass"></span> &nbsp;icon-magnifying-glass
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-circle-compass"></span> &nbsp;icon-circle-compass
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-linegraph"></span> &nbsp;icon-linegraph
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-mic"></span> &nbsp;icon-mic
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-strategy"></span> &nbsp;icon-strategy
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-beaker"></span> &nbsp;icon-beaker
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-caution"></span> &nbsp;icon-caution
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-recycle"></span> &nbsp;icon-recycle
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-anchor"></span> &nbsp;icon-anchor
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-profile-male"></span> &nbsp;icon-profile-male
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-profile-female"></span> &nbsp;icon-profile-female
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-bike"></span> &nbsp;icon-bike
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-wine"></span> &nbsp;icon-wine
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-hotairballoon"></span> &nbsp;icon-hotairballoon
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-globe"></span> &nbsp;icon-globe
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-genius"></span> &nbsp;icon-genius
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-map-pin"></span> &nbsp;icon-map-pin
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-dial"></span> &nbsp;icon-dial
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-chat"></span> &nbsp;icon-chat
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-heart"></span> &nbsp;icon-heart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-cloud"></span> &nbsp;icon-cloud
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-upload"></span> &nbsp;icon-upload
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-download"></span> &nbsp;icon-download
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-target"></span> &nbsp;icon-target
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-hazardous"></span> &nbsp;icon-hazardous
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-piechart"></span> &nbsp;icon-piechart
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-speedometer"></span> &nbsp;icon-speedometer
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-global"></span> &nbsp;icon-global
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-compass"></span> &nbsp;icon-compass
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-lifesaver"></span> &nbsp;icon-lifesaver
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-clock"></span> &nbsp;icon-clock
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-aperture"></span> &nbsp;icon-aperture
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-quote"></span> &nbsp;icon-quote
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-scope"></span> &nbsp;icon-scope
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-alarmclock"></span> &nbsp;icon-alarmclock
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-refresh"></span> &nbsp;icon-refresh
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-happy"></span> &nbsp;icon-happy
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-sad"></span> &nbsp;icon-sad
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-facebook"></span> &nbsp;icon-facebook
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-twitter"></span> &nbsp;icon-twitter
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-googleplus"></span> &nbsp;icon-googleplus
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-rss"></span> &nbsp;icon-rss
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-tumblr"></span> &nbsp;icon-tumblr
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-linkedin"></span> &nbsp;icon-linkedin
						</div>
						<div class="col-lg-4 col-md-6 demo-icon-wrap-s2">
							<span aria-hidden="true" class="icon-dribbble"></span> &nbsp;icon-dribbble
						</div>

					</div>
				</div>
            </section>
            <!-- section close -->

        </div>
        <!-- content close -->

        <a href="#" id="back-to-top"></a>
        
        <!-- footer begin -->
        <footer class="text-light">
            <div class="container">
                <div class="row g-custom-x">
                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>About Rentaly</h5>
                            <p>In tempor magna non ut labore sunt et in adipisicing do in proident veniam officia deserunt mollit velit aliquip sint fugiat reprehenderit sint anim pariatur deserunt id in ut non.</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>Contact Info</h5>
                            <address class="s1">
                                <span><i class="id-color fa fa-map-marker fa-lg"></i>08 W 36th St, New York, NY 10001</span>
                                <span><i class="id-color fa fa-phone fa-lg"></i>+1 333 9296</span>
                                <span><i class="id-color fa fa-envelope-o fa-lg"></i><a href="mailto:contact@example.com">contact@example.com</a></span>
                                <span><i class="id-color fa fa-file-pdf-o fa-lg"></i><a href="#">Download Brochure</a></span>
                            </address>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <h5>Quick Links</h5>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="widget">
                                    <ul>
                                        <li><a href="#">About</a></li>
                                        <li><a href="#">Blog</a></li>
                                        <li><a href="#">Careers</a></li>
                                        <li><a href="#">News</a></li>
                                        <li><a href="#">Partners</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="widget">
                            <h5>Social Network</h5>
                            <div class="social-icons">
                                <a href="#"><i class="fa fa-facebook fa-lg"></i></a>
                                <a href="#"><i class="fa fa-twitter fa-lg"></i></a>
                                <a href="#"><i class="fa fa-linkedin fa-lg"></i></a>
                                <a href="#"><i class="fa fa-pinterest fa-lg"></i></a>
                                <a href="#"><i class="fa fa-rss fa-lg"></i></a>
                            </div>
                        </div>    
                    </div>
                </div>
            </div>
            <div class="subfooter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="de-flex">
                                <div class="de-flex-col">
                                    <a href="index.html">
                                        Copyright 2023 - Rentaly by Designesia
                                    </a>
                                </div>
                                <ul class="menu-simple">
                                    <li><a href="#">Terms &amp; Conditions</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer close -->
        
    </div>


    <!-- Javascript Files
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/designesia.js"></script>

</body>

</html>