<?php
include('includes/header.php');
?>
<!-- content begin -->
<div class="no-bottom no-top" id="content">
    <div id="top"></div>

    <section id="section-preview" class="mt40 sm-mt-0" aria-label="section">
        <div class="container relative">
            <div class="row">
                <div class="col-md-12 text-center wow fadeInUp">
                    <div class="spacer-10 sm-hide"></div>

                    <div id="gallery" class="row gh-4 sequence">


                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="index.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/homepage-1.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Homepage 1</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="index-2.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/homepage-2.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Homepage 2</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="index-3.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/homepage-3.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Homepage 3</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="index-4.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/homepage-4.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Homepage 4</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="index-5.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/homepage-5.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Homepage 5</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="cars.html.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/cars.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Car List 1</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="cars-list.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/cars-list.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Car List 2</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="car-single.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/car-single.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Car Single</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="booking.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/booking.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Booking</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="about.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/about.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>About Us</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="news-grid-right-sidebar.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/news.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>News</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="news-single.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/news-single.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>News Single</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="account-dashboard.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/account-dashboard.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Account Dashboard</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="account-profile.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/account-profile.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Account Profile</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="account-orders.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/account-orders.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Account Orders</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="account-favorite.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/account-favorite.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Account Favorite Cars</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="login.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/login.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Login</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="register.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/register.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Register</h5>
                        </div>

                        <div class="col-md-4 item text-center mb20">
                            <a class="d_demo_img" target="_blank" href="404.html">
                                <span class="d-overlay"><span>Live Preview</span></span>
                                <img src="demo/preview/404.jpg" class="color img-fluid wow " alt="">
                            </a>
                            <h5>Page 404</h5>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

</div>
<?php
include('includes/scripts2.php');
include('includes/footer.php');
?>