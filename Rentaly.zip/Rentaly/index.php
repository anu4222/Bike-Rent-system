<?php
include('includes/header.php'); 
include('includes/inn.php'); 
?>


  <!-- ======= Footer ======= -->
    <?php
include('includes/scripts2.php');
include('includes/footer.php');
?>