<?php
include('includes/header.php');
?>
<div class="no-bottom no-top" id="content">
    <div id="top"></div>
    <!-- section begin -->
    <section id="subheader" class="jarallax text-light">
        <img src="images/background/subheader.jpg" class="jarallax-img" alt="">
        <div class="center-y relative text-center">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1>Register</h1>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- section close -->


    <section aria-label="section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <h3>Don't have an account? Register now.</h3>
                    
                    <div class="spacer-10"></div>

                    <form  class="form-border" method="post" action='code.php'>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="field-set">
                                    <label>Fist Name:</label>
                                    <input type='text' name='fist_name' id='name' class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="field-set">
                                    <label>Last Name:</label>
                                    <input type='text' name='last_name' id='name' class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="field-set">
                                    <label>Date Of Birth:</label>
                                    <input type='date' name='dob' id='name' class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="field-set">
                                    <label>Email Address:</label>
                                    <input type='text' name='email' id='email' class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="field-set">
                                    <label>Choose a Username:</label>
                                    <input type='text' name='username' id='username' class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="field-set">
                                    <label>Phone:</label>
                                    <input type='text' name='phone' id='phone' class="form-control" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="field-set">
                                    <label>Password:</label>
                                    <input type='text' name='password' id='password' class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="field-set">
                                    <label>Address:</label>
                                    <textarea name="address" id="" cols="10" rows="10" class="form-control" required></textarea required>
                                </div>
                            </div>

                            <div class="col-md-12">

                                <div id='submit' class="pull-left">
                                    <input type='submit' id='send_message' name="add_user" value='Register Now' class="btn-main color-2">
                                </div>

                            </div>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </section>


</div>
<!-- content close -->
<?php
include('includes/scripts2.php');
include('includes/footer.php');
?>